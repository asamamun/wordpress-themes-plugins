/**
 * Main JavaScript file for Final WDPF68 Theme
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Mobile menu toggle
        $('.menu-toggle').on('click', function() {
            $('.main-navigation').toggleClass('active');
        });
        
        // Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            var target = $(this.getAttribute('href'));
            if (target.length) {
                e.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 100
                }, 1000);
            }
        });
        
        // Back to top button
        var backToTop = $('<button class="back-to-top"><i class="fas fa-arrow-up"></i></button>');
        $('body').append(backToTop);
        
        $(window).scroll(function() {
            if ($(this).scrollTop() > 300) {
                backToTop.fadeIn();
            } else {
                backToTop.fadeOut();
            }
        });
        
        backToTop.on('click', function() {
            $('html, body').animate({scrollTop: 0}, 800);
            return false;
        });
        
    });
    
})(jQuery);

<?php
/**
 * Theme Customizer
 */

function finalwdpf68_customize_register($wp_customize) {
    
    // Carousel Section
    $wp_customize->add_section('finalwdpf68_carousel_section', array(
        'title'    => __('Carousel Settings', 'finalwdpf68'),
        'priority' => 30,
    ));
    
    // Add 5 carousel images
    for ($i = 1; $i <= 5; $i++) {
        $wp_customize->add_setting('carousel_image_' . $i, array(
            'default'   => get_template_directory_uri() . '/assets/images/carousel-' . $i . '.jpg',
            'transport' => 'refresh',
        ));
        
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'carousel_image_' . $i, array(
            'label'    => sprintf(__('Carousel Image %d (1600x500)', 'finalwdpf68'), $i),
            'section'  => 'finalwdpf68_carousel_section',
            'settings' => 'carousel_image_' . $i,
        )));
    }
    
    // Social Media Section
    $wp_customize->add_section('finalwdpf68_social_section', array(
        'title'    => __('Social Media Links', 'finalwdpf68'),
        'priority' => 31,
    ));
    
    $social_networks = array('facebook', 'twitter', 'instagram', 'youtube', 'linkedin');
    
    foreach ($social_networks as $network) {
        $wp_customize->add_setting('social_' . $network, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ));
        
        $wp_customize->add_control('social_' . $network, array(
            'label'    => sprintf(__('%s URL', 'finalwdpf68'), ucfirst($network)),
            'section'  => 'finalwdpf68_social_section',
            'type'     => 'url',
        ));
    }
    
    // Contact Information Section
    $wp_customize->add_section('finalwdpf68_contact_section', array(
        'title'    => __('Contact Information', 'finalwdpf68'),
        'priority' => 32,
    ));
    
    $wp_customize->add_setting('contact_phone', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('contact_phone', array(
        'label'   => __('Phone Number', 'finalwdpf68'),
        'section' => 'finalwdpf68_contact_section',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('contact_email', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('contact_email', array(
        'label'   => __('Email Address', 'finalwdpf68'),
        'section' => 'finalwdpf68_contact_section',
        'type'    => 'email',
    ));
    
    $wp_customize->add_setting('contact_address', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('contact_address', array(
        'label'   => __('Address', 'finalwdpf68'),
        'section' => 'finalwdpf68_contact_section',
        'type'    => 'textarea',
    ));
}
add_action('customize_register', 'finalwdpf68_customize_register');

// Helper function to get carousel images
function finalwdpf68_get_carousel_images() {
    $images = array();
    for ($i = 1; $i <= 5; $i++) {
        $image = get_theme_mod('carousel_image_' . $i);
        if ($image) {
            $images[] = $image;
        }
    }
    return $images;
}

?>

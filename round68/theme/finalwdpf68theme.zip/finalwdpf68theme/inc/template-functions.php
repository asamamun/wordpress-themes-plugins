<?php
/**
 * Template Helper Functions
 */

// Display social menu
function finalwdpf68_social_menu() {
    $social_links = array(
        'facebook'  => get_theme_mod('social_facebook'),
        'twitter'   => get_theme_mod('social_twitter'),
        'instagram' => get_theme_mod('social_instagram'),
        'youtube'   => get_theme_mod('social_youtube'),
        'linkedin'  => get_theme_mod('social_linkedin'),
    );
    
    $output = '<ul class="social-menu">';
    foreach ($social_links as $network => $url) {
        if ($url) {
            $output .= sprintf(
                '<li><a href="%s" target="_blank" rel="noopener"><i class="fab fa-%s"></i></a></li>',
                esc_url($url),
                esc_attr($network)
            );
        }
    }
    $output .= '</ul>';
    
    return $output;
}

// Display breadcrumbs
function finalwdpf68_breadcrumbs() {
    if (is_front_page()) return;
    
    echo '<nav class="breadcrumbs">';
    echo '<a href="' . home_url('/') . '">Home</a> &raquo; ';
    
    if (is_category() || is_single()) {
        the_category(' &bull; ');
        if (is_single()) {
            echo ' &raquo; ';
            the_title();
        }
    } elseif (is_page()) {
        echo the_title();
    } elseif (is_search()) {
        echo 'Search Results for: ' . get_search_query();
    } elseif (is_404()) {
        echo '404 Not Found';
    }
    
    echo '</nav>';
}

// Custom excerpt length
function finalwdpf68_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'finalwdpf68_excerpt_length');

// Custom excerpt more
function finalwdpf68_excerpt_more($more) {
    return '... <a class="read-more" href="' . get_permalink() . '">Read More</a>';
}
add_filter('excerpt_more', 'finalwdpf68_excerpt_more');

// Display post meta
function finalwdpf68_post_meta() {
    ?>
    <div class="post-meta">
        <span class="posted-on">
            <i class="far fa-calendar"></i> <?php echo get_the_date(); ?>
        </span>
        <span class="posted-by">
            <i class="far fa-user"></i> <?php the_author_posts_link(); ?>
        </span>
        <span class="comments-link">
            <i class="far fa-comments"></i> <?php comments_number('0 Comments', '1 Comment', '% Comments'); ?>
        </span>
    </div>
    <?php
}

?>

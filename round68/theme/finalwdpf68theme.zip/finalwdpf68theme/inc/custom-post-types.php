<?php
/**
 * Custom Post Types
 */

// Register Notice Post Type
function finalwdpf68_register_notice_post_type() {
    $labels = array(
        'name'                  => _x('Notices', 'Post Type General Name', 'finalwdpf68'),
        'singular_name'         => _x('Notice', 'Post Type Singular Name', 'finalwdpf68'),
        'menu_name'             => __('Notices', 'finalwdpf68'),
        'name_admin_bar'        => __('Notice', 'finalwdpf68'),
        'archives'              => __('Notice Archives', 'finalwdpf68'),
        'attributes'            => __('Notice Attributes', 'finalwdpf68'),
        'parent_item_colon'     => __('Parent Notice:', 'finalwdpf68'),
        'all_items'             => __('All Notices', 'finalwdpf68'),
        'add_new_item'          => __('Add New Notice', 'finalwdpf68'),
        'add_new'               => __('Add New', 'finalwdpf68'),
        'new_item'              => __('New Notice', 'finalwdpf68'),
        'edit_item'             => __('Edit Notice', 'finalwdpf68'),
        'update_item'           => __('Update Notice', 'finalwdpf68'),
        'view_item'             => __('View Notice', 'finalwdpf68'),
        'view_items'            => __('View Notices', 'finalwdpf68'),
        'search_items'          => __('Search Notice', 'finalwdpf68'),
        'not_found'             => __('Not found', 'finalwdpf68'),
        'not_found_in_trash'    => __('Not found in Trash', 'finalwdpf68'),
    );
    
    $args = array(
        'label'                 => __('Notice', 'finalwdpf68'),
        'description'           => __('School/College Notices', 'finalwdpf68'),
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'excerpt', 'author', 'comments'),
        'taxonomies'            => array('class_name'),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-megaphone',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    
    register_post_type('notice', $args);
}
add_action('init', 'finalwdpf68_register_notice_post_type', 0);

?>

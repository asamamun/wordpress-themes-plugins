<?php
/**
 * Custom Taxonomies
 */

// Register Class Name Taxonomy
function finalwdpf68_register_class_taxonomy() {
    $labels = array(
        'name'                       => _x('Class Names', 'Taxonomy General Name', 'finalwdpf68'),
        'singular_name'              => _x('Class Name', 'Taxonomy Singular Name', 'finalwdpf68'),
        'menu_name'                  => __('Class Names', 'finalwdpf68'),
        'all_items'                  => __('All Classes', 'finalwdpf68'),
        'parent_item'                => __('Parent Class', 'finalwdpf68'),
        'parent_item_colon'          => __('Parent Class:', 'finalwdpf68'),
        'new_item_name'              => __('New Class Name', 'finalwdpf68'),
        'add_new_item'               => __('Add New Class', 'finalwdpf68'),
        'edit_item'                  => __('Edit Class', 'finalwdpf68'),
        'update_item'                => __('Update Class', 'finalwdpf68'),
        'view_item'                  => __('View Class', 'finalwdpf68'),
        'separate_items_with_commas' => __('Separate classes with commas', 'finalwdpf68'),
        'add_or_remove_items'        => __('Add or remove classes', 'finalwdpf68'),
        'choose_from_most_used'      => __('Choose from the most used', 'finalwdpf68'),
        'popular_items'              => __('Popular Classes', 'finalwdpf68'),
        'search_items'               => __('Search Classes', 'finalwdpf68'),
        'not_found'                  => __('Not Found', 'finalwdpf68'),
    );
    
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'show_in_rest'               => true,
    );
    
    register_taxonomy('class_name', array('notice', 'post'), $args);
}
add_action('init', 'finalwdpf68_register_class_taxonomy', 0);

?>

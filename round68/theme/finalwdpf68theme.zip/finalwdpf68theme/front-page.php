<?php
/**
 * Front Page Template
 */
get_header();
?>

<main class="site-content">
    <div class="container">
        <?php get_template_part('template-parts/carousel'); ?>
        
        <div class="row mt-4">
            <!-- Latest News Section -->
            <div class="col-md-8">
                <h2><?php _e('Latest News', 'finalwdpf68'); ?></h2>
                <div class="news-grid">
                    <?php
                    $latest_posts = new WP_Query(array(
                        'posts_per_page' => 6,
                        'post_status'    => 'publish',
                    ));
                    
                    if ($latest_posts->have_posts()) :
                        while ($latest_posts->have_posts()) : $latest_posts->the_post();
                    ?>
                        <article class="news-item">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="news-thumbnail">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail('featured-medium'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <?php finalwdpf68_post_meta(); ?>
                            <?php the_excerpt(); ?>
                        </article>
                    <?php
                        endwhile;
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
            </div>
            
            <!-- Notices Sidebar -->
            <aside class="col-md-4">
                <div class="notices-widget">
                    <h3><?php _e('Recent Notices', 'finalwdpf68'); ?></h3>
                    <?php
                    $notices = new WP_Query(array(
                        'post_type'      => 'notice',
                        'posts_per_page' => 5,
                    ));
                    
                    if ($notices->have_posts()) :
                        echo '<ul class="notices-list">';
                        while ($notices->have_posts()) : $notices->the_post();
                    ?>
                        <li>
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            <span class="notice-date"><?php echo get_the_date(); ?></span>
                        </li>
                    <?php
                        endwhile;
                        echo '</ul>';
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
                
                <?php get_sidebar(); ?>
            </aside>
        </div>
    </div>
</main>

<?php get_footer(); ?>

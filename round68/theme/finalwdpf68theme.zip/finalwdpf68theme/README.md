# Final WDPF68 Theme

## Education and Newspaper WordPress Theme

### Features

#### Theme Support
- Title Tag
- Post Thumbnails (Featured Images)
- Custom Logo
- Custom Header
- Custom Background
- HTML5 Support
- Post Formats
- Automatic Feed Links
- Editor Styles
- Block Styles
- Responsive Embeds
- Wide Alignment

#### Navigation Menus
1. **Primary Menu** - Main navigation in header
2. **Social Menu** - Social media links
3. **Footer Menu** - Footer navigation

#### Custom Post Types
- **Notice** - For school/college notices and announcements
  - Supports: Title, Editor, Thumbnail, Excerpt, Author, Comments
  - Has archive page
  - Integrated with Class Name taxonomy

#### Custom Taxonomies
- **Class Name** - Hierarchical taxonomy for organizing content by class
  - Works with: Notices and Posts
  - Hierarchical structure (like categories)

#### Widget Areas
- **Sidebar** - Main sidebar widget area
- **Footer Widget 1** - First footer column
- **Footer Widget 2** - Second footer column
- **Footer Widget 3** - Third footer column

#### Customizer Options
- **Carousel Images** - 5 carousel image slots (1600x500px recommended)
- **Social Media Links** - Facebook, Twitter, Instagram, YouTube, LinkedIn
- **Contact Information** - Phone, Email, Address

#### Template Hierarchy
- `front-page.php` - Homepage with carousel and latest news
- `index.php` - Blog archive
- `single.php` - Single post
- `single-notice.php` - Single notice
- `page.php` - Static pages
- `archive.php` - Archive pages
- `header.php` - Site header
- `footer.php` - Site footer with widgets
- `sidebar.php` - Sidebar
- `template-parts/carousel.php` - Carousel component

### Installation

1. Upload the theme folder to `/wp-content/themes/`
2. Activate the theme in WordPress admin
3. Go to Appearance → Customize to configure:
   - Upload carousel images
   - Add social media links
   - Set contact information
4. Go to Appearance → Menus to create:
   - Primary menu
   - Social menu
   - Footer menu
5. Go to Appearance → Widgets to add widgets to:
   - Sidebar
   - Footer areas (3 columns)

### Usage

#### Adding Notices
1. Go to Notices → Add New
2. Enter notice title and content
3. Set featured image (optional)
4. Assign to Class Name taxonomy
5. Publish

#### Setting Carousel Images
1. Go to Appearance → Customize
2. Open "Carousel Settings"
3. Upload up to 5 images (1600x500px recommended)
4. Click "Publish"

#### Configuring Menus
1. Go to Appearance → Menus
2. Create menu and assign to location:
   - Primary Menu (main navigation)
   - Social Menu (social links)
   - Footer Menu (footer navigation)

#### Adding Footer Widgets
1. Go to Appearance → Widgets
2. Drag widgets to:
   - Footer Widget Area 1
   - Footer Widget Area 2
   - Footer Widget Area 3

### File Structure

```
finalwdpf68theme/
├── assets/
│   └── js/
│       └── main.js
├── inc/
│   ├── custom-post-types.php
│   ├── custom-taxonomies.php
│   ├── customizer.php
│   └── template-functions.php
├── template-parts/
│   └── carousel.php
├── archive.php
├── footer.php
├── front-page.php
├── functions.php
├── header.php
├── index.php
├── page.php
├── sidebar.php
├── single.php
├── single-notice.php
├── style.css
└── README.md
```

### Customization

#### Adding More Carousel Images
Edit `inc/customizer.php` and change the loop limit:
```php
for ($i = 1; $i <= 10; $i++) { // Change 5 to 10
```

#### Adding More Social Networks
Edit `inc/customizer.php` and add to the array:
```php
$social_networks = array('facebook', 'twitter', 'instagram', 'youtube', 'linkedin', 'pinterest');
```

#### Custom Image Sizes
Defined in `functions.php`:
- `carousel-image` - 1600x500px (hard crop)
- `featured-large` - 800x450px (hard crop)
- `featured-medium` - 400x300px (hard crop)
- `featured-small` - 200x150px (hard crop)

### Template Hierarchy Explained

WordPress follows this order when loading templates:

**Homepage:**
1. `front-page.php` ✓
2. `home.php`
3. `index.php`

**Single Post:**
1. `single-{post-type}.php` (e.g., `single-notice.php`) ✓
2. `single.php` ✓
3. `index.php`

**Page:**
1. `page-{slug}.php`
2. `page-{id}.php`
3. `page.php` ✓
4. `index.php`

**Archive:**
1. `archive-{post-type}.php`
2. `archive.php` ✓
3. `index.php`

**Category:**
1. `category-{slug}.php`
2. `category-{id}.php`
3. `category.php`
4. `archive.php` ✓
5. `index.php`

### Support

For issues or questions, contact the theme developer.

### Credits

- Bootstrap 5.3.8
- Font Awesome (for icons)
- WordPress Codex

### License

GNU General Public License v2 or later

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="container">
        <div class="header-top">
            <div class="site-branding">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <h1 class="site-title">
                        <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                    </h1>
                    <p class="site-description"><?php bloginfo('description'); ?></p>
                <?php endif; ?>
            </div>
            
            <div class="header-contact">
                <?php if (get_theme_mod('contact_phone')) : ?>
                    <span><i class="fas fa-phone"></i> <?php echo esc_html(get_theme_mod('contact_phone')); ?></span>
                <?php endif; ?>
                <?php if (get_theme_mod('contact_email')) : ?>
                    <span><i class="fas fa-envelope"></i> <?php echo esc_html(get_theme_mod('contact_email')); ?></span>
                <?php endif; ?>
            </div>
        </div>
        
        <nav class="main-navigation">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_class'     => 'primary-menu',
                'container'      => false,
                'fallback_cb'    => false,
            ));
            ?>
        </nav>
        
        <div class="social-navigation">
            <?php echo finalwdpf68_social_menu(); ?>
        </div>
    </div>
</header>

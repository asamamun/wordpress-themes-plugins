<?php
/**
 * Final WDPF68 Theme Functions
 * Education and Newspaper WordPress Theme
 */

// Theme Setup
function finalwdpf68_theme_setup() {
    
    // Add theme support features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('custom-header');
    add_theme_support('custom-background');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('post-formats', array('aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat'));
    add_theme_support('automatic-feed-links');
    add_theme_support('editor-styles');
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    
    // Set content width
    if (!isset($content_width)) {
        $content_width = 1200;
    }
    
    // Register navigation menus
    register_nav_menus(array(
        'primary'   => __('Primary Menu', 'finalwdpf68'),
        'social'    => __('Social Menu', 'finalwdpf68'),
        'footer'    => __('Footer Menu', 'finalwdpf68'),
    ));
    
    // Add image sizes
    add_image_size('carousel-image', 1600, 500, true);
    add_image_size('featured-large', 800, 450, true);
    add_image_size('featured-medium', 400, 300, true);
    add_image_size('featured-small', 200, 150, true);
}
add_action('after_setup_theme', 'finalwdpf68_theme_setup');

// Enqueue styles and scripts
function finalwdpf68_enqueue_assets() {
    // Styles
    wp_enqueue_style('finalwdpf68-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css', array(), '5.3.8');
    
    // Scripts
    wp_enqueue_script('bootstrap-bundle', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js', array(), '5.3.8', true);
    wp_enqueue_script('finalwdpf68-script', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'finalwdpf68_enqueue_assets');

// Register widget areas
function finalwdpf68_widgets_init() {
    // Sidebar
    register_sidebar(array(
        'name'          => __('Sidebar', 'finalwdpf68'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here to appear in your sidebar.', 'finalwdpf68'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    // Footer widgets (3 columns)
    for ($i = 1; $i <= 3; $i++) {
        register_sidebar(array(
            'name'          => sprintf(__('Footer Widget Area %d', 'finalwdpf68'), $i),
            'id'            => 'footer-' . $i,
            'description'   => sprintf(__('Footer widget area %d', 'finalwdpf68'), $i),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ));
    }
}
add_action('widgets_init', 'finalwdpf68_widgets_init');

// Include theme functions
require_once get_template_directory() . '/inc/custom-post-types.php';
require_once get_template_directory() . '/inc/custom-taxonomies.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/template-functions.php';

?>

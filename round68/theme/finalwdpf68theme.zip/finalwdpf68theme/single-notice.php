<?php get_header(); ?>

<main class="site-content">
    <div class="container">
        <?php finalwdpf68_breadcrumbs(); ?>
        
        <div class="row">
            <div class="col-md-8">
                <?php while (have_posts()) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('notice-single'); ?>>
                        <header class="entry-header">
                            <h1 class="entry-title"><?php the_title(); ?></h1>
                            <div class="notice-meta">
                                <span class="notice-date">
                                    <i class="far fa-calendar"></i> <?php echo get_the_date(); ?>
                                </span>
                                <?php
                                $terms = get_the_terms(get_the_ID(), 'class_name');
                                if ($terms && !is_wp_error($terms)) :
                                    echo '<span class="notice-class"><i class="fas fa-graduation-cap"></i> ';
                                    $class_names = array();
                                    foreach ($terms as $term) {
                                        $class_names[] = $term->name;
                                    }
                                    echo implode(', ', $class_names);
                                    echo '</span>';
                                endif;
                                ?>
                            </div>
                        </header>
                        
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="post-thumbnail">
                                <?php the_post_thumbnail('featured-large'); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="entry-content">
                            <?php the_content(); ?>
                        </div>
                    </article>
                    
                    <?php
                    if (comments_open() || get_comments_number()) :
                        comments_template();
                    endif;
                    ?>
                <?php endwhile; ?>
            </div>
            
            <aside class="col-md-4">
                <div class="related-notices">
                    <h3><?php _e('Related Notices', 'finalwdpf68'); ?></h3>
                    <?php
                    $related = new WP_Query(array(
                        'post_type'      => 'notice',
                        'posts_per_page' => 5,
                        'post__not_in'   => array(get_the_ID()),
                    ));
                    
                    if ($related->have_posts()) :
                        echo '<ul class="related-notices-list">';
                        while ($related->have_posts()) : $related->the_post();
                            ?>
                            <li>
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                <span class="notice-date"><?php echo get_the_date(); ?></span>
                            </li>
                            <?php
                        endwhile;
                        echo '</ul>';
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>
                
                <?php get_sidebar(); ?>
            </aside>
        </div>
    </div>
</main>

<?php get_footer(); ?>

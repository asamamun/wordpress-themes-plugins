<?php get_header(); ?>

<main class="site-content">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php if (have_posts()) : ?>
                    <div class="posts-list">
                        <?php while (have_posts()) : the_post(); ?>
                            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="post-thumbnail">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail('featured-large'); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <header class="entry-header">
                                    <h2 class="entry-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h2>
                                    <?php finalwdpf68_post_meta(); ?>
                                </header>
                                
                                <div class="entry-summary">
                                    <?php the_excerpt(); ?>
                                </div>
                            </article>
                        <?php endwhile; ?>
                        
                        <div class="pagination">
                            <?php
                            the_posts_pagination(array(
                                'mid_size'  => 2,
                                'prev_text' => __('&laquo; Previous', 'finalwdpf68'),
                                'next_text' => __('Next &raquo;', 'finalwdpf68'),
                            ));
                            ?>
                        </div>
                    </div>
                <?php else : ?>
                    <p><?php _e('No posts found.', 'finalwdpf68'); ?></p>
                <?php endif; ?>
            </div>
            
            <aside class="col-md-4">
                <?php get_sidebar(); ?>
            </aside>
        </div>
    </div>
</main>

<?php get_footer(); ?>

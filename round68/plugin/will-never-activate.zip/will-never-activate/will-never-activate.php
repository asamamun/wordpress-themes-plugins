<?php
/*
Plugin Name: Will Never Activate
Description: This plugin is designed to never activate. It is used to test the plugin activation system.
Version: 1.0
Author: WordPress
*/
function will_never_activate() {
     global $wp_version;
    if( version_compare( $wp_version, '50.0', '<') )
    // wp_die('This plugin is designed to never activate. Current WordPress version: ' . $wp_version);
    wp_die(plugins_url());
}
register_activation_hook(__FILE__, 'will_never_activate');

//register deactivation hook
function will_never_deactivate() {
    //  wp_die("we can call this fx with deactivation");
}
register_deactivation_hook(__FILE__, 'will_never_deactivate');

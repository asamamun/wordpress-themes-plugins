<?php
/*
Plugin Name: Censor words
Plugin URI: http://example.com
Description: Censor Plugin
Version: 1.0
Author: Round 68 WDPF
Author URI: http://example.com
Text Domain: censor
Domain Path: /languages
*/
function censor_words($content) {
    $censored_words = array('sissy', 'damn', 'asshole', 'bitch', 'dick', 'fucker', 'boom', 'shit');
    $censored_content = str_ireplace($censored_words, '*****', $content);
    return $censored_content;
}
add_filter('the_content', 'censor_words');
//want to censor in user comments also
add_filter('comment_text', 'censor_words');

# Sticky Footer News Ticker Plugin

## Overview
This WordPress plugin creates a sticky footer that displays scrolling news items like a marquee. It includes a complete admin interface for managing news content and customizing the display.

## Features
- **Sticky Footer**: News ticker stays fixed at the bottom of the page
- **Marquee Animation**: Smooth scrolling text from right to left
- **Admin Interface**: Complete CRUD operations for news items
- **Customizable Settings**: Control speed, colors, and visibility
- **URL Support**: Make news items clickable with optional URLs
- **Responsive Design**: Works on all device sizes

## Installation
1. Upload the `stickey-footer` folder to your `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Sticky Footer' in your admin menu to start adding news

## Usage

### Adding News Items
1. Navigate to **Sticky Footer → Add News**
2. Enter the news title and optional URL
3. Click "Add News"
4. View all current news items in the table below the form

### Managing News Items
1. Go to **Sticky Footer → Manage News**
2. View all news items in a table format
3. Delete items using the "Delete" button
4. See a live preview of how the footer will appear

### Settings Configuration
1. Visit **Sticky Footer → Settings**
2. Configure the following options:
   - **Enable/Disable** the sticky footer
   - **Scroll Speed**: Adjust animation speed (5-100 seconds)
   - **Background Color**: Choose footer background color
   - **Text Color**: Choose news text color
3. Save your settings

## Technical Implementation

### WordPress APIs Used
- **Options API**: `add_option()`, `update_option()`, `get_option()`, `delete_option()`
- **Settings API**: Custom settings implementation
- **Admin Menu API**: `add_menu_page()`, `add_submenu_page()`
- **Hooks**: `admin_menu`, `wp_footer`

### Key Functions
- `sticky_footer_menu()` - Creates admin menu structure
- `sticky_footer_display()` - Renders frontend sticky footer
- `sticky_footer_add_news_page()` - Handles news creation
- `sticky_footer_manage_news_page()` - Handles news management
- `sticky_footer_settings_page()` - Handles plugin settings

### Data Structure
News items are stored as an array in WordPress options:
```php
[
    [
        'id' => 'unique_id',
        'title' => 'News Title',
        'url' => 'https://example.com',
        'date' => '2024-01-01 12:00:00'
    ]
]
```

### CSS Animation
The marquee effect is implemented using CSS keyframes:
```css
@keyframes marquee {
    0% { transform: translateX(100%); }
    100% { transform: translateX(-100%); }
}
```

## File Structure
```
stickey-footer/
├── stickey-footer.php          # Main plugin file
├── sticky-footer-add-news.php   # Add news admin page
├── sticky-footer-manage-news.php # Manage news admin page
├── sticky-footer-settings.php   # Settings admin page
├── admin-style.css             # Admin panel styling
└── README.md                   # This documentation
```

## Security Features
- Input sanitization using `sanitize_text_field()`
- URL validation using `esc_url_raw()`
- Output escaping using `esc_html()` and `esc_attr()`
- Nonce verification for form submissions
- Capability checks for admin access

## Customization
You can customize the appearance by modifying:
- CSS styles in the `sticky_footer_display()` function
- Animation speed in the CSS keyframes
- HTML structure of the news items
- Color schemes in the settings

## Troubleshooting
- **Footer not appearing**: Check if enabled in settings
- **News not scrolling**: Verify CSS animations are not blocked
- **Admin pages not loading**: Check file permissions
- **Colors not applying**: Clear browser cache

## Version History
- **1.0**: Initial release with basic functionality

## Author
Round 68 WDPF
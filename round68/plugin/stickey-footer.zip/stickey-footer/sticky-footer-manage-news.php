<div class="wrap">
    <h1>Manage News Items</h1>
    
    <?php
    $news_items = get_option('sticky_footer_news', array());
    
    if (!empty($news_items)) {
        echo '<table class="widefat fixed striped">';
        echo '<thead><tr><th>News Title</th><th>URL</th><th>Date Added</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        
        foreach ($news_items as $item) {
            echo '<tr>';
            echo '<td>' . esc_html($item['title']) . '</td>';
            echo '<td>' . ($item['url'] ? '<a href="' . esc_url($item['url']) . '" target="_blank">' . esc_url($item['url']) . '</a>' : 'No URL') . '</td>';
            echo '<td>' . esc_html($item['date']) . '</td>';
            echo '<td>';
            echo '<a href="admin.php?page=sticky-footer-manage-news&action=delete&id=' . esc_attr($item['id']) . '" class="button button-small" onclick="return confirm(\'Are you sure you want to delete this news item?\')">Delete</a>';
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        echo '<p><a href="admin.php?page=sticky-footer-add-news" class="button button-primary">Add New News</a></p>';
    } else {
        echo '<div class="notice notice-info"><p>No news items found. <a href="admin.php?page=sticky-footer-add-news">Add your first news item</a></p></div>';
    }
    ?>
    
    <h2>Preview</h2>
    <p>Here's how your sticky footer will appear on the frontend:</p>
    <div style="position: relative; height: 60px; border: 1px solid #ddd; background: #f9f9f9; overflow: hidden;">
        <div style="position: absolute; bottom: 0; left: 0; width: 100%; background-color: #333; color: white; padding: 10px 0; white-space: nowrap;">
            <div style="display: inline-block; animation: preview-marquee 15s linear infinite;">
                <?php
                if (!empty($news_items)) {
                    foreach ($news_items as $item) {
                        $link_open = $item['url'] ? '<a href="' . esc_url($item['url']) . '" target="_blank" style="color: inherit; text-decoration: none;">' : '';
                        $link_close = $item['url'] ? '</a>' : '';
                        echo $link_open . esc_html($item['title']) . $link_close . ' &nbsp; &nbsp; &nbsp; &nbsp; ';
                    }
                } else {
                    echo 'No news items to display';
                }
                ?>
            </div>
        </div>
    </div>
    
    <style>
    @keyframes preview-marquee {
        0% { transform: translateX(100%); }
        100% { transform: translateX(-100%); }
    }
    </style>
</div>
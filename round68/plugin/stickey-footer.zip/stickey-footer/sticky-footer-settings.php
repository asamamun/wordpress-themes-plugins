<div class="wrap">
    <h1>Sticky Footer Settings</h1>
    
    <form method="post" action="">
        <table class="form-table">
            <tr>
                <th scope="row">Enable Sticky Footer</th>
                <td>
                    <input type="checkbox" name="sticky_footer_enabled" id="sticky_footer_enabled" value="1" 
                           <?php checked(1, get_option('sticky_footer_enabled', 1)); ?> />
                    <label for="sticky_footer_enabled">Enable the sticky footer news ticker</label>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="scroll_speed">Scroll Speed</label></th>
                <td>
                    <input name="scroll_speed" type="number" id="scroll_speed" 
                           value="<?php echo esc_attr(get_option('sticky_footer_speed', 30)); ?>" 
                           class="small-text" min="5" max="100">
                    <p class="description">Scroll speed in seconds (5-100). Lower numbers = faster scrolling.</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="background_color">Background Color</label></th>
                <td>
                    <input name="background_color" type="color" id="background_color" 
                           value="<?php echo esc_attr(get_option('sticky_footer_bg_color', '#333333')); ?>">
                    <p class="description">Choose the background color for the sticky footer</p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="text_color">Text Color</label></th>
                <td>
                    <input name="text_color" type="color" id="text_color" 
                           value="<?php echo esc_attr(get_option('sticky_footer_text_color', '#ffffff')); ?>">
                    <p class="description">Choose the text color for the news items</p>
                </td>
            </tr>
        </table>
        
        <?php submit_button('Save Settings', 'primary', 'save_settings'); ?>
    </form>
    
    <h2>Current Configuration</h2>
    <table class="form-table">
        <tr>
            <th>Status:</th>
            <td><?php echo get_option('sticky_footer_enabled', 1) ? '<span style="color: green;">Enabled</span>' : '<span style="color: red;">Disabled</span>'; ?></td>
        </tr>
        <tr>
            <th>Scroll Speed:</th>
            <td><?php echo esc_html(get_option('sticky_footer_speed', 30)); ?> seconds</td>
        </tr>
        <tr>
            <th>Background Color:</th>
            <td>
                <span style="display: inline-block; width: 20px; height: 20px; background-color: <?php echo esc_attr(get_option('sticky_footer_bg_color', '#333333')); ?>; border: 1px solid #ddd;"></span>
                <?php echo esc_html(get_option('sticky_footer_bg_color', '#333333')); ?>
            </td>
        </tr>
        <tr>
            <th>Text Color:</th>
            <td>
                <span style="display: inline-block; width: 20px; height: 20px; background-color: <?php echo esc_attr(get_option('sticky_footer_text_color', '#ffffff')); ?>; border: 1px solid #ddd;"></span>
                <?php echo esc_html(get_option('sticky_footer_text_color', '#ffffff')); ?>
            </td>
        </tr>
        <tr>
            <th>News Items:</th>
            <td><?php echo count(get_option('sticky_footer_news', array())); ?> items</td>
        </tr>
    </table>
</div>
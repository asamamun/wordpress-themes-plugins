<div class="wrap">
    <h1>Add News Item</h1>
    
    <form method="post" action="">
        <table class="form-table">
            <tr>
                <th scope="row"><label for="news_title">News Title</label></th>
                <td>
                    <input name="news_title" type="text" id="news_title" class="regular-text" required>
                    <p class="description">Enter the news headline to display</p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="news_url">News URL (Optional)</label></th>
                <td>
                    <input name="news_url" type="url" id="news_url" class="regular-text">
                    <p class="description">Enter URL if you want the news to be clickable</p>
                </td>
            </tr>
        </table>
        
        <?php submit_button('Add News', 'primary', 'submit_news'); ?>
    </form>
    
    <h2>Current News Items</h2>
    <?php
    $news_items = get_option('sticky_footer_news', array());
    if (!empty($news_items)) {
        echo '<table class="widefat fixed striped">';
        echo '<thead><tr><th>News Title</th><th>URL</th><th>Date Added</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        foreach ($news_items as $item) {
            echo '<tr>';
            echo '<td>' . esc_html($item['title']) . '</td>';
            echo '<td>' . ($item['url'] ? '<a href="' . esc_url($item['url']) . '" target="_blank">' . esc_url($item['url']) . '</a>' : 'No URL') . '</td>';
            echo '<td>' . esc_html($item['date']) . '</td>';
            echo '<td><a href="admin.php?page=sticky-footer-manage-news&action=delete&id=' . esc_attr($item['id']) . '" class="button button-small" onclick="return confirm(\'Are you sure?\')">Delete</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p>No news items added yet.</p>';
    }
    ?>
</div>
<?php
/*
Plugin Name: Sticky Footer News Ticker
Plugin URI: http://proqoder.com/sticky-footer-news-ticker
Description: Displays a sticky footer with scrolling news like a marquee
Version: 1.0
Author: Round 68 WDPF
Author URI: http://example.com
Text Domain: sticky-footer
Domain Path: /languages
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

define('STICKY_FOOTER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('STICKY_FOOTER_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Create admin menu
function sticky_footer_menu() {
    add_menu_page(
        'Sticky Footer',
        'Sticky Footer',
        'manage_options',
        'sticky-footer',
        'sticky_footer_main_page',
        'dashicons-admin-site',
        30
    );
    
    add_submenu_page(
        'sticky-footer',
        'Add News',
        'Add News',
        'manage_options',
        'sticky-footer-add-news',
        'sticky_footer_add_news_page'
    );
    
    add_submenu_page(
        'sticky-footer',
        'Manage News',
        'Manage News',
        'manage_options',
        'sticky-footer-manage-news',
        'sticky_footer_manage_news_page'
    );
    
    add_submenu_page(
        'sticky-footer',
        'Settings',
        'Settings',
        'manage_options',
        'sticky-footer-settings',
        'sticky_footer_settings_page'
    );
}
add_action('admin_menu', 'sticky_footer_menu');

// Main plugin page
function sticky_footer_main_page() {
    echo '<div class="wrap">';
    echo '<h1>Sticky Footer News Ticker</h1>';
    echo '<p>This plugin displays a sticky footer with scrolling news.</p>';
    echo '<h2>Quick Links</h2>';
    echo '<ul>';
    echo '<li><a href="admin.php?page=sticky-footer-add-news">Add New News</a></li>';
    echo '<li><a href="admin.php?page=sticky-footer-manage-news">Manage News</a></li>';
    echo '<li><a href="admin.php?page=sticky-footer-settings">Settings</a></li>';
    echo '</ul>';
    echo '</div>';
}

// Add News Page
function sticky_footer_add_news_page() {
    if (isset($_POST['submit_news'])) {
        $news_title = sanitize_text_field($_POST['news_title']);
        $news_url = esc_url_raw($_POST['news_url']);
        
        if (!empty($news_title)) {
            $news_items = get_option('sticky_footer_news', array());
            $news_items[] = array(
                'id' => uniqid(),
                'title' => $news_title,
                'url' => $news_url,
                'date' => current_time('mysql')
            );
            update_option('sticky_footer_news', $news_items);
            echo '<div class="notice notice-success"><p>News added successfully!</p></div>';
        }
    }
    
    include STICKY_FOOTER_PLUGIN_PATH . 'sticky-footer-add-news.php';
}

// Manage News Page
function sticky_footer_manage_news_page() {
    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        $news_id = sanitize_text_field($_GET['id']);
        $news_items = get_option('sticky_footer_news', array());
        
        foreach ($news_items as $key => $item) {
            if ($item['id'] == $news_id) {
                unset($news_items[$key]);
                break;
            }
        }
        
        update_option('sticky_footer_news', array_values($news_items));
        echo '<div class="notice notice-success"><p>News deleted successfully!</p></div>';
    }
    
    include STICKY_FOOTER_PLUGIN_PATH . 'sticky-footer-manage-news.php';
}

// Settings Page
function sticky_footer_settings_page() {
    if (isset($_POST['save_settings'])) {
        $speed = intval($_POST['scroll_speed']);
        $bgcolor = sanitize_hex_color($_POST['background_color']);
        $textcolor = sanitize_hex_color($_POST['text_color']);
        $enabled = isset($_POST['sticky_footer_enabled']) ? 1 : 0;
        
        update_option('sticky_footer_speed', $speed);
        update_option('sticky_footer_bg_color', $bgcolor);
        update_option('sticky_footer_text_color', $textcolor);
        update_option('sticky_footer_enabled', $enabled);
        
        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }
    
    include STICKY_FOOTER_PLUGIN_PATH . 'sticky-footer-settings.php';
}

// Frontend: Display sticky footer
function sticky_footer_display() {
    $enabled = get_option('sticky_footer_enabled', 1);
    if (!$enabled) return;
    
    $news_items = get_option('sticky_footer_news', array());
    if (empty($news_items)) return;
    
    $speed = get_option('sticky_footer_speed', 30);
    $bgcolor = get_option('sticky_footer_bg_color', '#333333');
    $textcolor = get_option('sticky_footer_text_color', '#ffffff');
    
    echo '<div id="sticky-footer-news" style="
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: ' . $bgcolor . ';
        color: ' . $textcolor . ';
        padding: 10px 0;
        z-index: 9999;
        overflow: hidden;
        white-space: nowrap;
    ">
    <div class="news-container" style="
        display: inline-block;
        animation: marquee ' . $speed . 's linear infinite;
    ">
    ';
    
    foreach ($news_items as $item) {
        $link_open = $item['url'] ? '<a href="' . $item['url'] . '" target="_blank" style="color: inherit; text-decoration: none;">' : '';
        $link_close = $item['url'] ? '</a>' : '';
        echo $link_open . esc_html($item['title']) . $link_close . ' &nbsp; &nbsp; &nbsp; &nbsp; ';
    }
    
    echo '</div>
    </div>
    
    <style>
    @keyframes marquee {
        0% { transform: translateX(100%); }
        100% { transform: translateX(-100%); }
    }
    </style>
    
    <script>
    // Adjust body padding to prevent content overlap
    document.addEventListener("DOMContentLoaded", function() {
        var footer = document.getElementById("sticky-footer-news");
        if (footer) {
            var footerHeight = footer.offsetHeight;
            document.body.style.paddingBottom = footerHeight + "px";
        }
    });
    </script>
    ';
}
add_action('wp_footer', 'sticky_footer_display');

// Enqueue admin styles
function sticky_footer_admin_styles() {
    wp_enqueue_style('sticky-footer-admin', STICKY_FOOTER_PLUGIN_URL . 'admin-style.css');
}
add_action('admin_enqueue_scripts', 'sticky_footer_admin_styles');

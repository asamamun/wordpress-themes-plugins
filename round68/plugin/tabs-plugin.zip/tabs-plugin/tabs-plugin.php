<?php
/*
Plugin Name: Advanced Tabs Plugin
Plugin URI: http://example.com
Description: A comprehensive tabs plugin with multiple tabs, options for each tab, and admin settings
Version: 1.0
Author: Round 68 WDPF
Author URI: http://example.com
Text Domain: tabs-plugin
Domain Path: /languages
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

define('TABS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TABS_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Register activation hook
register_activation_hook(__FILE__, 'tabs_plugin_activate');

function tabs_plugin_activate() {
    // Create default options for each tab
    $default_tabs = array(
        'tab1' => array(
            'title' => 'Tab 1',
            'content' => 'This is the content for Tab 1.',
            'enabled' => 1,
            'order' => 1,
            'icon' => 'dashicons-admin-generic'
        ),
        'tab2' => array(
            'title' => 'Tab 2',
            'content' => 'This is the content for Tab 2.',
            'enabled' => 1,
            'order' => 2,
            'icon' => 'dashicons-admin-tools'
        ),
        'tab3' => array(
            'title' => 'Tab 3',
            'content' => 'This is the content for Tab 3.',
            'enabled' => 1,
            'order' => 3,
            'icon' => 'dashicons-admin-appearance'
        )
    );
    
    update_option('tabs_plugin_tabs', $default_tabs);
}

// Create admin menu
function tabs_plugin_menu() {
    add_menu_page(
        'Tabs Plugin',
        'Tabs Plugin',
        'manage_options',
        'tabs-plugin',
        'tabs_plugin_main_page',
        'dashicons-menu-alt',
        30
    );
    
    add_submenu_page(
        'tabs-plugin',
        'Manage Tabs',
        'Manage Tabs',
        'manage_options',
        'tabs-plugin',
        'tabs_plugin_main_page'
    );
    
    add_submenu_page(
        'tabs-plugin',
        'Add New Tab',
        'Add New Tab',
        'manage_options',
        'tabs-plugin-add',
        'tabs_plugin_add_page'
    );
    
    add_submenu_page(
        'tabs-plugin',
        'Settings',
        'Settings',
        'manage_options',
        'tabs-plugin-settings',
        'tabs_plugin_settings_page'
    );
}
add_action('admin_menu', 'tabs_plugin_menu');

// Main plugin page - Tab management
function tabs_plugin_main_page() {
    // Handle tab ordering
    if (isset($_POST['save_order'])) {
        $tabs = get_option('tabs_plugin_tabs', array());
        $orders = $_POST['tab_order'];
        
        foreach ($orders as $index => $tab_key) {
            $tabs[$tab_key]['order'] = $index + 1;
        }
        
        update_option('tabs_plugin_tabs', $tabs);
        echo '<div class="notice notice-success"><p>Tab order updated successfully!</p></div>';
    }
    
    // Handle tab enable/disable
    if (isset($_GET['action']) && isset($_GET['tab_key'])) {
        $action = sanitize_text_field($_GET['action']);
        $tab_key = sanitize_text_field($_GET['tab_key']);
        
        $tabs = get_option('tabs_plugin_tabs', array());
        
        if ($action == 'enable' && isset($tabs[$tab_key])) {
            $tabs[$tab_key]['enabled'] = 1;
            update_option('tabs_plugin_tabs', $tabs);
            echo '<div class="notice notice-success"><p>Tab enabled successfully!</p></div>';
        } elseif ($action == 'disable' && isset($tabs[$tab_key])) {
            $tabs[$tab_key]['enabled'] = 0;
            update_option('tabs_plugin_tabs', $tabs);
            echo '<div class="notice notice-success"><p>Tab disabled successfully!</p></div>';
        } elseif ($action == 'delete' && isset($tabs[$tab_key])) {
            unset($tabs[$tab_key]);
            update_option('tabs_plugin_tabs', $tabs);
            echo '<div class="notice notice-success"><p>Tab deleted successfully!</p></div>';
        }
    }
    
    $tabs = get_option('tabs_plugin_tabs', array());
    
    // Sort tabs by order
    uasort($tabs, function($a, $b) {
        return $a['order'] - $b['order'];
    });
    
    echo '<div class="wrap">';
    echo '<h1>Tabs Plugin Manager</h1>';
    echo '<p>Manage your tabs, their content, and settings.</p>';
    
    echo '<form method="post" action="">';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Order</th><th>Tab Name</th><th>Status</th><th>Actions</th></tr></thead>';
    echo '<tbody id="sortable-tabs">';
    
    $counter = 1;
    foreach ($tabs as $key => $tab) {
        $status = $tab['enabled'] ? 'Active' : 'Inactive';
        $status_class = $tab['enabled'] ? 'status-active' : 'status-inactive';
        $toggle_text = $tab['enabled'] ? 'Disable' : 'Enable';
        $toggle_action = $tab['enabled'] ? 'disable' : 'enable';
        
        echo '<tr data-tab-key="' . esc_attr($key) . '">';
        echo '<td class="order-column"><span class="dashicons dashicons-move"></span> ' . $counter . ' <input type="hidden" name="tab_order[]" value="' . esc_attr($key) . '"></td>';
        echo '<td>' . esc_html($tab['title']) . '</td>';
        echo '<td><span class="tab-status ' . $status_class . '">' . $status . '</span></td>';
        echo '<td>';
        echo '<a href="admin.php?page=tabs-plugin&tab_key=' . esc_attr($key) . '&action=' . $toggle_action . '" class="button button-small">' . $toggle_text . '</a> ';
        echo '<a href="admin.php?page=tabs-plugin&tab_key=' . esc_attr($key) . '&action=delete" class="button button-small button-secondary" onclick="return confirm(\'Are you sure you want to delete this tab?\')">Delete</a> ';
        echo '<a href="admin.php?page=tabs-plugin-add&tab_key=' . esc_attr($key) . '" class="button button-small">Edit</a>';
        echo '</td>';
        echo '</tr>';
        $counter++;
    }
    
    echo '</tbody>';
    echo '</table>';
    submit_button('Save Order', 'primary', 'save_order');
    echo '</form>';
    
    echo '<p><a href="admin.php?page=tabs-plugin-add" class="button button-primary">Add New Tab</a></p>';
    echo '</div>';
    
    // Add jQuery UI for drag and drop
    wp_enqueue_script('jquery-ui-sortable');
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('#sortable-tabs').sortable({
            placeholder: 'ui-state-highlight',
            update: function(event, ui) {
                $(this).find('tr').each(function(index) {
                    $(this).find('input[type="hidden"]').val($(this).data('tab-key'));
                });
            }
        });
    });
    </script>
    <?php
}

// Add/Edit tab page
function tabs_plugin_add_page() {
    $tab_key = isset($_GET['tab_key']) ? sanitize_text_field($_GET['tab_key']) : null;
    $tabs = get_option('tabs_plugin_tabs', array());
    
    if (isset($_POST['save_tab'])) {
        $new_tab_key = sanitize_text_field($_POST['tab_key']);
        $title = sanitize_text_field($_POST['title']);
        $content = wp_kses_post($_POST['content']);
        $enabled = isset($_POST['enabled']) ? 1 : 0;
        $icon = sanitize_text_field($_POST['icon']);
        
        if (empty($new_tab_key)) {
            $new_tab_key = 'tab_' . time();
        }
        
        $tabs[$new_tab_key] = array(
            'title' => $title,
            'content' => $content,
            'enabled' => $enabled,
            'order' => isset($tabs[$new_tab_key]) ? $tabs[$new_tab_key]['order'] : (count($tabs) + 1),
            'icon' => $icon
        );
        
        update_option('tabs_plugin_tabs', $tabs);
        echo '<div class="notice notice-success"><p>Tab saved successfully!</p></div>';
    }
    
    $tab_data = array(
        'title' => '',
        'content' => '',
        'enabled' => 1,
        'icon' => 'dashicons-admin-generic'
    );
    
    if ($tab_key && isset($tabs[$tab_key])) {
        $tab_data = $tabs[$tab_key];
    }
    
    echo '<div class="wrap">';
    echo '<h1>' . ($tab_key ? 'Edit Tab' : 'Add New Tab') . '</h1>';
    
    echo '<form method="post" action="">';
    echo '<table class="form-table">';
    echo '<tr><th scope="row">Tab Key</th><td>';
    if ($tab_key) {
        echo '<input type="text" name="tab_key" value="' . esc_attr($tab_key) . '" readonly class="regular-text">';
        echo '<p class="description">Tab key cannot be changed after creation.</p>';
    } else {
        echo '<input type="text" name="tab_key" value="" placeholder="e.g., my_custom_tab" class="regular-text">';
        echo '<p class="description">Unique identifier for this tab. Leave empty for auto-generated key.</p>';
    }
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Title</th><td>';
    echo '<input type="text" name="title" value="' . esc_attr($tab_data['title']) . '" required class="regular-text">';
    echo '<p class="description">Display title for this tab.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Icon</th><td>';
    echo '<select name="icon" class="regular-text">';
    $icons = array(
        'dashicons-admin-generic' => 'Generic',
        'dashicons-admin-appearance' => 'Appearance',
        'dashicons-admin-collapse' => 'Collapse',
        'dashicons-admin-comments' => 'Comments',
        'dashicons-admin-home' => 'Home',
        'dashicons-admin-media' => 'Media',
        'dashicons-admin-page' => 'Page',
        'dashicons-admin-plugins' => 'Plugins',
        'dashicons-admin-settings' => 'Settings',
        'dashicons-admin-tools' => 'Tools',
        'dashicons-admin-users' => 'Users',
        'dashicons-format-image' => 'Image',
        'dashicons-format-video' => 'Video',
        'dashicons-welcome-write-blog' => 'Write Blog',
        'dashicons-welcome-view-site' => 'View Site'
    );
    
    foreach ($icons as $icon_value => $icon_label) {
        $selected = ($icon_value == $tab_data['icon']) ? 'selected' : '';
        echo '<option value="' . esc_attr($icon_value) . '" ' . $selected . '>' . $icon_label . '</option>';
    }
    echo '</select>';
    echo '<p class="description">Choose an icon for this tab.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Content</th><td>';
    echo '<textarea name="content" rows="10" cols="50" class="large-text">' . esc_textarea($tab_data['content']) . '</textarea>';
    echo '<p class="description">HTML content for this tab. You can use basic HTML tags.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Status</th><td>';
    echo '<input type="checkbox" name="enabled" value="1" ' . checked(1, $tab_data['enabled'], false) . '> Enabled';
    echo '<p class="description">Check to enable this tab on the frontend.</p>';
    echo '</td></tr>';
    
    echo '</table>';
    submit_button($tab_key ? 'Update Tab' : 'Add Tab', 'primary', 'save_tab');
    echo '</form>';
    echo '</div>';
}

// Settings page
function tabs_plugin_settings_page() {
    if (isset($_POST['save_settings'])) {
        $settings = array(
            'container_class' => sanitize_text_field($_POST['container_class']),
            'tab_list_class' => sanitize_text_field($_POST['tab_list_class']),
            'tab_content_class' => sanitize_text_field($_POST['tab_content_class']),
            'animation_speed' => intval($_POST['animation_speed']),
            'default_active_tab' => sanitize_text_field($_POST['default_active_tab'])
        );
        
        update_option('tabs_plugin_settings', $settings);
        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }
    
    $settings = get_option('tabs_plugin_settings', array(
        'container_class' => 'tabs-container',
        'tab_list_class' => 'tabs-nav',
        'tab_content_class' => 'tabs-content',
        'animation_speed' => 300,
        'default_active_tab' => ''
    ));
    
    echo '<div class="wrap">';
    echo '<h1>Tabs Plugin Settings</h1>';
    echo '<p>Configure global settings for the tabs plugin.</p>';
    
    echo '<form method="post" action="">';
    echo '<table class="form-table">';
    
    echo '<tr><th scope="row">Container Class</th><td>';
    echo '<input type="text" name="container_class" value="' . esc_attr($settings['container_class']) . '" class="regular-text">';
    echo '<p class="description">CSS class for the main tabs container.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Tab List Class</th><td>';
    echo '<input type="text" name="tab_list_class" value="' . esc_attr($settings['tab_list_class']) . '" class="regular-text">';
    echo '<p class="description">CSS class for the tab navigation list.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Tab Content Class</th><td>';
    echo '<input type="text" name="tab_content_class" value="' . esc_attr($settings['tab_content_class']) . '" class="regular-text">';
    echo '<p class="description">CSS class for the tab content area.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Animation Speed</th><td>';
    echo '<input type="number" name="animation_speed" value="' . esc_attr($settings['animation_speed']) . '" class="small-text"> milliseconds';
    echo '<p class="description">Speed of tab transition animation.</p>';
    echo '</td></tr>';
    
    echo '<tr><th scope="row">Default Active Tab</th><td>';
    $tabs = get_option('tabs_plugin_tabs', array());
    echo '<select name="default_active_tab" class="regular-text">';
    echo '<option value="">None (first active)</option>';
    foreach ($tabs as $key => $tab) {
        if ($tab['enabled']) {
            $selected = ($key == $settings['default_active_tab']) ? 'selected' : '';
            echo '<option value="' . esc_attr($key) . '" ' . $selected . '>' . esc_html($tab['title']) . '</option>';
        }
    }
    echo '</select>';
    echo '<p class="description">Which tab should be active by default.</p>';
    echo '</td></tr>';
    
    echo '</table>';
    submit_button('Save Settings', 'primary', 'save_settings');
    echo '</form>';
    echo '</div>';
}

// Enqueue frontend scripts and styles
function tabs_plugin_frontend_assets() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('tabs-script', TABS_PLUGIN_URL . 'assets/tabs.js', array('jquery'), '1.0', true);
    wp_enqueue_style('tabs-style', TABS_PLUGIN_URL . 'assets/tabs.css', array(), '1.0');
}
add_action('wp_enqueue_scripts', 'tabs_plugin_frontend_assets');

// Shortcode to display tabs
function tabs_shortcode($atts) {
    $atts = shortcode_atts(array(
        'exclude_disabled' => 'true',
        'show_count' => 'false'
    ), $atts);
    
    $tabs = get_option('tabs_plugin_tabs', array());
    $settings = get_option('tabs_plugin_settings', array(
        'container_class' => 'tabs-container',
        'tab_list_class' => 'tabs-nav',
        'tab_content_class' => 'tabs-content',
        'animation_speed' => 300,
        'default_active_tab' => ''
    ));
    
    // Filter out disabled tabs if requested
    if ($atts['exclude_disabled'] === 'true') {
        $enabled_tabs = array();
        foreach ($tabs as $key => $tab) {
            if ($tab['enabled']) {
                $enabled_tabs[$key] = $tab;
            }
        }
        $tabs = $enabled_tabs;
    }
    
    // Sort by order
    uasort($tabs, function($a, $b) {
        return $a['order'] - $b['order'];
    });
    
    if (empty($tabs)) {
        return '<p>No tabs available.</p>';
    }
    
    $output = '<div class="' . esc_attr($settings['container_class']) . '">';
    
    // Tab navigation
    $output .= '<ul class="' . esc_attr($settings['tab_list_class']) . '">';
    $first = true;
    foreach ($tabs as $key => $tab) {
        $active_class = ($first || ($settings['default_active_tab'] && $key == $settings['default_active_tab'])) ? ' active' : '';
        $output .= '<li class="tab-nav-item' . $active_class . '" data-tab="' . esc_attr($key) . '">';
        $output .= '<span class="dashicons ' . esc_attr($tab['icon']) . '"></span> ';
        $output .= esc_html($tab['title']);
        $output .= '</li>';
        $first = false;
    }
    $output .= '</ul>';
    
    // Tab content
    $output .= '<div class="' . esc_attr($settings['tab_content_class']) . '">';
    $first = true;
    foreach ($tabs as $key => $tab) {
        $active_class = ($first || ($settings['default_active_tab'] && $key == $settings['default_active_tab'])) ? ' active' : '';
        $output .= '<div class="tab-content-item' . $active_class . '" id="tab-' . esc_attr($key) . '">';
        $output .= wp_kses_post($tab['content']);
        $output .= '</div>';
        $first = false;
    }
    $output .= '</div>';
    
    $output .= '</div>';
    
    return $output;
}
add_shortcode('tabs', 'tabs_shortcode');

// Add sample content to footer for demonstration
function tabs_demo_content() {
    echo '<div style="margin: 20px 0; padding: 15px; background: #f9f9f9; border: 1px solid #ddd;">';
    echo '<h3>Demo Tabs</h3>';
    echo '[tabs]';
    echo '</div>';
}
// Uncomment the line below to add demo content to the footer
// add_action('wp_footer', 'tabs_demo_content');
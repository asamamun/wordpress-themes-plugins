# Advanced Tabs Plugin Development Tutorial

## Overview
This tutorial demonstrates how to build a comprehensive WordPress plugin with multiple tabs, options for each tab, and admin settings. We'll cover all aspects of WordPress plugin development including Options API, Settings API, admin menus, and frontend functionality.

## Plugin Structure

```
tabs-plugin/
├── tabs-plugin.php          # Main plugin file
├── assets/
│   ├── tabs.js             # JavaScript for tab functionality
│   └── tabs.css            # CSS styling for tabs
└── tutorial.md             # This tutorial
```

## Key Concepts Covered

### 1. WordPress Plugin Headers
Every WordPress plugin starts with a header comment block that provides metadata about the plugin:

```php
/*
Plugin Name: Advanced Tabs Plugin
Plugin URI: http://example.com
Description: A comprehensive tabs plugin with multiple tabs, options for each tab, and admin settings
Version: 1.0
Author: Round 68 WDPF
Author URI: http://example.com
Text Domain: tabs-plugin
Domain Path: /languages
*/
```

### 2. Security Check
Always check if the file is accessed directly and exit if so:

```php
if (!defined('ABSPATH')) {
    exit;
}
```

### 3. Constants Definition
Define constants for plugin paths and URLs:

```php
define('TABS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TABS_PLUGIN_PATH', plugin_dir_path(__FILE__));
```

## Options API Implementation

### Registration and Activation
Use WordPress hooks to register activation functions:

```php
register_activation_hook(__FILE__, 'tabs_plugin_activate');

function tabs_plugin_activate() {
    // Create default options for each tab
    $default_tabs = array(
        'tab1' => array(
            'title' => 'Tab 1',
            'content' => 'This is the content for Tab 1.',
            'enabled' => 1,
            'order' => 1,
            'icon' => 'dashicons-admin-generic'
        ),
        // ... more tabs
    );
    
    update_option('tabs_plugin_tabs', $default_tabs);
}
```

### Options API Methods Used
- `update_option()` - Store data in WordPress database
- `get_option()` - Retrieve data from WordPress database
- `add_option()` - Add new option (used internally)
- `delete_option()` - Remove option (not used in this example)

## Admin Menu System

### Creating Admin Menus
Use `add_menu_page()` and `add_submenu_page()` functions:

```php
function tabs_plugin_menu() {
    add_menu_page(
        'Tabs Plugin',           // Page title
        'Tabs Plugin',           // Menu title
        'manage_options',        // Capability required
        'tabs-plugin',           // Menu slug
        'tabs_plugin_main_page', // Callback function
        'dashicons-menu-alt',    // Icon
        30                       // Position
    );
    
    add_submenu_page(
        'tabs-plugin',           // Parent slug
        'Manage Tabs',           // Page title
        'Manage Tabs',           // Menu title
        'manage_options',        // Capability
        'tabs-plugin',           // Menu slug
        'tabs_plugin_main_page'  // Callback
    );
    
    // ... more submenus
}
add_action('admin_menu', 'tabs_plugin_menu');
```

## Database Schema

The plugin stores tab data as serialized arrays in WordPress options table:

### Tabs Data Structure
```php
'tabs_plugin_tabs' => array(
    'tab1' => array(
        'title' => 'Tab 1',
        'content' => 'Content here...',
        'enabled' => 1,
        'order' => 1,
        'icon' => 'dashicons-admin-generic'
    ),
    'tab2' => array(
        'title' => 'Tab 2',
        'content' => 'Content here...',
        'enabled' => 1,
        'order' => 2,
        'icon' => 'dashicons-admin-tools'
    )
)
```

### Settings Data Structure
```php
'tabs_plugin_settings' => array(
    'container_class' => 'tabs-container',
    'tab_list_class' => 'tabs-nav',
    'tab_content_class' => 'tabs-content',
    'animation_speed' => 300,
    'default_active_tab' => ''
)
```

## Admin Pages Implementation

### Main Management Page
Handles tab listing, reordering, and bulk actions:

```php
function tabs_plugin_main_page() {
    // Handle various actions
    if (isset($_POST['save_order'])) {
        // Handle tab ordering
    }
    
    if (isset($_GET['action']) && isset($_GET['tab_key'])) {
        // Handle enable/disable/delete actions
    }
    
    // Display the admin interface
    $tabs = get_option('tabs_plugin_tabs', array());
    // ... render HTML
}
```

### Add/Edit Tab Page
Manages individual tab properties:

```php
function tabs_plugin_add_page() {
    if (isset($_POST['save_tab'])) {
        $new_tab_key = sanitize_text_field($_POST['tab_key']);
        $title = sanitize_text_field($_POST['title']);
        $content = wp_kses_post($_POST['content']);
        $enabled = isset($_POST['enabled']) ? 1 : 0;
        $icon = sanitize_text_field($_POST['icon']);
        
        // Update options
        $tabs[$new_tab_key] = array(
            'title' => $title,
            'content' => $content,
            'enabled' => $enabled,
            'order' => isset($tabs[$new_tab_key]) ? $tabs[$new_tab_key]['order'] : (count($tabs) + 1),
            'icon' => $icon
        );
        
        update_option('tabs_plugin_tabs', $tabs);
    }
    
    // Render form
}
```

### Settings Page
Global plugin configuration:

```php
function tabs_plugin_settings_page() {
    if (isset($_POST['save_settings'])) {
        $settings = array(
            'container_class' => sanitize_text_field($_POST['container_class']),
            'tab_list_class' => sanitize_text_field($_POST['tab_list_class']),
            'tab_content_class' => sanitize_text_field($_POST['tab_content_class']),
            'animation_speed' => intval($_POST['animation_speed']),
            'default_active_tab' => sanitize_text_field($_POST['default_active_tab'])
        );
        
        update_option('tabs_plugin_settings', $settings);
    }
    
    // Render settings form
}
```

## Security Measures

### Input Sanitization
Always sanitize user inputs:

```php
// Text inputs
$title = sanitize_text_field($_POST['title']);

// URLs
$url = esc_url_raw($_POST['url']);

// Numbers
$number = intval($_POST['number']);

// HTML content (with allowed tags)
$content = wp_kses_post($_POST['content']);

// Text with allowed HTML
$text = wp_kses($_POST['text'], array(
    'a' => array('href' => array()),
    'strong' => array(),
    'em' => array()
));
```

### Output Escaping
Always escape data when outputting:

```php
// HTML attributes
echo 'value="' . esc_attr($value) . '"';

// HTML content
echo esc_html($content);

// URLs
echo esc_url($url);

// Textareas
echo esc_textarea($textarea_content);
```

### Capability Checks
Verify user permissions:

```php
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}
```

## Frontend Implementation

### Asset Enqueuing
Properly enqueue scripts and styles:

```php
function tabs_plugin_frontend_assets() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('tabs-script', TABS_PLUGIN_URL . 'assets/tabs.js', array('jquery'), '1.0', true);
    wp_enqueue_style('tabs-style', TABS_PLUGIN_URL . 'assets/tabs.css', array(), '1.0');
}
add_action('wp_enqueue_scripts', 'tabs_plugin_frontend_assets');
```

### Shortcode Creation
Create a shortcode to display tabs anywhere:

```php
function tabs_shortcode($atts) {
    $atts = shortcode_atts(array(
        'exclude_disabled' => 'true',
        'show_count' => 'false'
    ), $atts);
    
    // Build HTML output
    $output = '<div class="tabs-container">';
    // ... tab navigation and content
    return $output;
}
add_shortcode('tabs', 'tabs_shortcode');
```

## JavaScript Functionality

The tabs use jQuery for smooth transitions:

```javascript
jQuery(document).ready(function($) {
    // Handle tab clicks
    $('.tabs-nav .tab-nav-item').on('click', function(e) {
        e.preventDefault();
        
        var tabId = $(this).data('tab');
        var container = $(this).closest('.tabs-container');
        var contentArea = container.find('.tabs-content');
        
        // Remove active class from all tabs
        container.find('.tab-nav-item').removeClass('active');
        contentArea.find('.tab-content-item').removeClass('active');
        
        // Add active class to clicked tab
        $(this).addClass('active');
        contentArea.find('#tab-' + tabId).addClass('active');
    });
});
```

## CSS Styling

The responsive design adapts to different screen sizes:

```css
.tabs-nav {
    display: flex;
    flex-wrap: wrap;
}

@media (max-width: 768px) {
    .tabs-nav {
        flex-direction: column;
    }
}
```

## Best Practices Demonstrated

### 1. Proper Hook Usage
- Use appropriate WordPress hooks (`admin_menu`, `wp_enqueue_scripts`, etc.)
- Register activation/deactivation hooks when needed

### 2. Data Validation
- Always sanitize inputs
- Validate data types and formats
- Escape outputs to prevent XSS

### 3. User Experience
- Provide feedback with notices
- Use familiar WordPress UI patterns
- Implement drag-and-drop for reordering

### 4. Performance Optimization
- Efficient database queries
- Conditional asset loading
- Proper caching considerations

## Extending the Plugin

### Adding New Features
To add new functionality:

1. **Database**: Add new options using `update_option()`
2. **Admin UI**: Create new admin pages with `add_submenu_page()`
3. **Frontend**: Modify shortcode or add new ones
4. **Settings**: Extend settings page with new options

### Example: Adding Tab Categories
```php
// Add category field to tab data structure
'tab1' => array(
    'title' => 'Tab 1',
    'content' => 'Content',
    'category' => 'general',  // New field
    // ... other fields
)

// Modify shortcode to filter by category
function tabs_shortcode($atts) {
    $atts = shortcode_atts(array(
        'category' => '',  // New attribute
        // ... other attributes
    ), $atts);
    
    if (!empty($atts['category'])) {
        // Filter tabs by category
    }
}
```

## Common WordPress Plugin Development Patterns

### 1. Singleton Pattern
For complex plugins with shared state:

```php
class Tabs_Plugin {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init();
    }
}
```

### 2. Object-Oriented Approach
Organize code into classes:

```php
class Tabs_Admin {
    public function init() {
        add_action('admin_menu', array($this, 'create_menu'));
    }
    
    public function create_menu() {
        // Create admin menu
    }
}
```

### 3. Internationalization
Prepare for translation:

```php
__('Tab Title', 'tabs-plugin')
_e('Click here', 'tabs-plugin')
_x('Save', 'button text', 'tabs-plugin')
```

## Conclusion

This tutorial demonstrates a complete WordPress plugin with:

- ✅ Multiple tabs with individual settings
- ✅ Options API for data storage
- ✅ Settings API for configuration
- ✅ Admin menu with multiple pages
- ✅ Secure input/output handling
- ✅ Frontend functionality with shortcode
- ✅ Responsive design
- ✅ JavaScript interactions

The plugin serves as a comprehensive example of WordPress plugin development best practices, covering all the major APIs and patterns used in professional WordPress development.
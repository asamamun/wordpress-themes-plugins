jQuery(document).ready(function($) {
    // Handle tab clicks
    $('.tabs-nav .tab-nav-item').on('click', function(e) {
        e.preventDefault();
        
        var tabId = $(this).data('tab');
        var container = $(this).closest('.tabs-container');
        var contentArea = container.find('.tabs-content');
        
        // Remove active class from all tabs
        container.find('.tab-nav-item').removeClass('active');
        contentArea.find('.tab-content-item').removeClass('active');
        
        // Add active class to clicked tab
        $(this).addClass('active');
        contentArea.find('#tab-' + tabId).addClass('active');
    });
    
    // Initialize first tab as active if none is active
    $('.tabs-container').each(function() {
        var $container = $(this);
        var $navItems = $container.find('.tab-nav-item');
        var $contentItems = $container.find('.tab-content-item');
        
        // If no active tab is found, activate the first one
        if ($navItems.filter('.active').length === 0) {
            $navItems.first().addClass('active');
            $contentItems.first().addClass('active');
        }
    });
});
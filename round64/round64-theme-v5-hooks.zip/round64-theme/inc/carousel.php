<?php
// Add Theme Customizer settings for Bootstrap 5.3 Carousel
function mytheme_customize_register($wp_customize) {
    // Add a section for the carousel
    $wp_customize->add_section('mytheme_carousel_section', array(
        'title' => __('Carousel Settings', 'mytheme'),
        'priority' => 30,
    ));

    // Loop to create settings and controls for 3 slides
    for ($i = 1; $i <= 3; $i++) {
        // Image setting
        $wp_customize->add_setting("mytheme_carousel_image_$i", array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw',
        ));

        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "mytheme_carousel_image_$i", array(
            'label' => __("Slide $i Image", 'mytheme'),
            'section' => 'mytheme_carousel_section',
            'settings' => "mytheme_carousel_image_$i",
        )));

        // Title setting
        $wp_customize->add_setting("mytheme_carousel_title_$i", array(
            'default' => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));

        $wp_customize->add_control("mytheme_carousel_title_$i", array(
            'label' => __("Slide $i Title", 'mytheme'),
            'section' => 'mytheme_carousel_section',
            'type' => 'text',
        ));

        // Link setting
        $wp_customize->add_setting("mytheme_carousel_link_$i", array(
            'default' => '',
            'sanitize_callback' => 'esc_url_raw',
        ));

        $wp_customize->add_control("mytheme_carousel_link_$i", array(
            'label' => __("Slide $i Link", 'mytheme'),
            'section' => 'mytheme_carousel_section',
            'type' => 'url',
        ));
    }
}
add_action('customize_register', 'mytheme_customize_register');
?>
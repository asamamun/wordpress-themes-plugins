<?php
function style_title($title) {
   return strtoupper($title); 
}
add_filter("the_title", "style_title");


function add_ads($content) {
    $ads = ['abc.gif','bashundhara.jpg','nagad.jpg','tata.gif'];
    $getrandomads = $ads[array_rand($ads)];
    $imagelocation = get_template_directory_uri() . '/assets/ads/' . $getrandomads;
    $minsToRead = round(str_word_count($content) / 200);
    return "<hr><span class='text-muted'>{$minsToRead} minutes read</span><hr>" .$content . "<hr><div class='ads d-flex justify-content-center'>
    <img src='{$imagelocation}' alt='ads'>
    </div>";
}
add_filter("the_content", "add_ads");
<?php
// Register Custom Taxonomy: Mood
function register_mood_taxonomy() {
    $labels = array(
        'name'                       => _x( 'Moods', 'Taxonomy General Name', 'text_domain' ),
        'singular_name'              => _x( 'Mood', 'Taxonomy Singular Name', 'text_domain' ),
        'menu_name'                  => __( 'Moods', 'text_domain' ),
        'all_items'                  => __( 'All Moods', 'text_domain' ),
        'parent_item'                => __( 'Parent Mood', 'text_domain' ),
        'parent_item_colon'          => __( 'Parent Mood:', 'text_domain' ),
        'new_item_name'              => __( 'New Mood Name', 'text_domain' ),
        'add_new_item'               => __( 'Add New Mood', 'text_domain' ),
        'edit_item'                  => __( 'Edit Mood', 'text_domain' ),
        'update_item'                => __( 'Update Mood', 'text_domain' ),
        'view_item'                  => __( 'View Mood', 'text_domain' ),
        'separate_items_with_commas' => __( 'Separate moods with commas', 'text_domain' ),
        'add_or_remove_items'        => __( 'Add or remove moods', 'text_domain' ),
        'choose_from_most_used'      => __( 'Choose from the most used moods', 'text_domain' ),
        'popular_items'              => __( 'Popular Moods', 'text_domain' ),
        'search_items'               => __( 'Search Moods', 'text_domain' ),
        'not_found'                  => __( 'No Moods found.', 'text_domain' ),
    );

    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true, // Non-hierarchical (like tags)
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
        'show_in_rest'               => true, // Enable for block editor (Gutenberg)
        'rewrite'                    => array( 'slug' => 'mood' ),
    );

    register_taxonomy( 'mood', array( 'post','hotnews' ), $args );

    // Insert mood terms if they don't exist
    $moods = array( 'Happy', 'Sad', 'Angry' );
    foreach ( $moods as $mood ) {
        if ( ! term_exists( $mood, 'mood' ) ) {
            wp_insert_term( $mood, 'mood' );
        }
    }
}
add_action( 'init', 'register_mood_taxonomy', 0 );

// Enqueue Bootstrap 5.3.3 and Font Awesome
function enqueue_bootstrap_and_font_awesome() {
    // Enqueue Bootstrap CSS
    wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', array(), '5.3.3' );
    // Enqueue Bootstrap JS
    wp_enqueue_script( 'bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', array( 'jquery' ), '5.3.3', true );
    // Enqueue Font Awesome CSS
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
}
//add_action( 'wp_enqueue_scripts', 'enqueue_bootstrap_and_font_awesome' );
?>
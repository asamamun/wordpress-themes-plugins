<?php
// Bootstrap 5.3 Carousel Template
$slides = [];
for ($i = 1; $i <= 3; $i++) {
    $image = get_theme_mod("mytheme_carousel_image_$i", '');
    $title = get_theme_mod("mytheme_carousel_title_$i", '');
    $link = get_theme_mod("mytheme_carousel_link_$i", '');
    if ($image) { // Only include slides with an image
        $slides[] = [
            'image' => $image,
            'title' => $title,
            'link' => $link,
        ];
    }
}
if (!empty($slides)) :
?>
<div id="mythemeCarousel" class="carousel slide" data-bs-ride="carousel">
    <!-- Indicators -->
    <div class="carousel-indicators">
        <?php foreach ($slides as $index => $slide) : ?>
            <button type="button" data-bs-target="#mythemeCarousel" data-bs-slide-to="<?php echo $index; ?>" class="<?php echo $index === 0 ? 'active' : ''; ?>" aria-current="<?php echo $index === 0 ? 'true' : 'false'; ?>" aria-label="Slide <?php echo $index + 1; ?>"></button>
        <?php endforeach; ?>
    </div>
    <!-- Slides -->
    <div class="carousel-inner">
        <?php foreach ($slides as $index => $slide) : ?>
            <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                <?php if ($slide['link']) : ?>
                    <a href="<?php echo esc_url($slide['link']); ?>">
                        <img src="<?php echo esc_url($slide['image']); ?>" class="d-block w-100" alt="<?php echo esc_attr($slide['title']); ?>">
                    </a>
                <?php else : ?>
                    <img src="<?php echo esc_url($slide['image']); ?>" class="d-block w-100" alt="<?php echo esc_attr($slide['title']); ?>">
                <?php endif;?>
                <?php if ($slide['title']) : ?>
                    <div class="carousel-caption d-none d-md-block">
                        <h3><?php echo esc_html($slide['title']); ?></h3>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <!-- Controls -->
    <button class="carousel-control-prev" type="button" data-bs-target="#mythemeCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#mythemeCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php endif; ?>
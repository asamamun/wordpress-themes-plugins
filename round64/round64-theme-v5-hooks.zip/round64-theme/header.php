<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo( 'name' ); ?>- <?= is_home()?"HOME": get_the_title(); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">

</head>

<body <?php body_class(); ?>>
  <div class="container">
    <!-- navbar start -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="main-menu">
      <?php
      wp_nav_menu([
        'theme_location' => 'header-menu',
        'container' => false,
        'depth' => 2,
        'menu_class' => 'navbar-nav ms-auto mb-2 mb-lg-0',
        'fallback_cb' => '__return_false',
        'walker' => new bootstrap_5_wp_nav_menu_walker()
      ]);
      ?>
    </div>
  </div>
</nav>

<?php if(is_front_page()): ?>

    <!-- navbar end -->
     <div class="row">
      <div class="col-5">
         <!-- hotnews start -->
<?php get_template_part('components/hotnews'); ?>
 <!-- hotnews end -->
      </div>
      <div class="col-7">
            <!-- carousel start -->
<?php get_template_part('components/carousel'); ?>
    <!-- carousel end -->
      </div>
     </div>
  <?php endif; ?>

     <!-- header image -->
<?php if ( get_header_image() ) : ?>
  <div class="custom-header">
    <img src="<?php header_image(); ?>" 
         width="<?php echo get_custom_header()->width; ?>" 
         height="<?php echo get_custom_header()->height; ?>" 
         alt="Header Image" />
  </div>
<?php endif; ?>

     <!-- header image end -->
<!--      <div>
        testing: <?php echo get_template_directory_uri(); ?>, <?php echo get_template_directory(); ?>
     </div> -->
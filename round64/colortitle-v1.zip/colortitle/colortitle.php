<?php
/*
 Plugin Name: Title The Color
 Plugin URI: http://example.com/wordpress-plugins/halloween-plugin
 Description: This plugin will color your title based on the color you select in the settings.
 Version: 1.1
Author: ASA Al-Mamun
Author URI: http://example.com
 Text Domain: round64
 License: GPLv2
 */

// Function to color the title
function round64_color_title($title) {
    $color = get_option('round64_color_title_color', '#FFD700'); // Default to yellow
    if ($color && !is_admin()) {
        $title = '<span style="color: ' . esc_attr($color) . ';">' . $title . '</span>';
    }
    return $title;
}
add_filter('the_title', 'round64_color_title');

// Function to handle the settings page
function round64_color_title_settings() {
    ?>
    <div class="wrap">
        <h2>Color Title Settings</h2>
        <p>Select a color to apply to your post titles.</p>
        <form method="post" action="options.php">
            <?php settings_fields('round64_color_title_settings_group'); ?>
            <table class="form-table">
                <tr valign="top">
                <th scope="row">Title Color</th>
                <td><input type="color" name="round64_color_title_color" value="<?php echo esc_attr(get_option('round64_color_title_color', '#FFD700')); ?>"></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Function to add the settings menu
function round64_color_title_menu() {
    add_options_page('Color Title 1', 'Color Title 2', 'manage_options', 'color-title-settings', 'round64_color_title_settings');
}
add_action('admin_menu', 'round64_color_title_menu');

// Register the setting
function round64_register_settings() {
    register_setting('round64_color_title_settings_group', 'round64_color_title_color');
}
add_action('admin_init', 'round64_register_settings');
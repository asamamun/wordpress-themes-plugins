<?php
/**
 * Plugin Name: Popup Advertisement
 * Description: A simple plugin to display a popup advertisement on the home page.
 * Version: 1.0
 * Author: Asa Al-Mamun
 * Author URI: https://asamamun.wordpress.com/
 * License: GNU GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: popup-advertisement
 * tags: popup, advertisement, home page, plugin
 */

// Add the admin menu
add_action('admin_menu', 'popup_advertisement_menu');

function popup_advertisement_menu() {
    add_menu_page(
        'Popup Advertisement Page',
        'Popup Advertisement',
        'manage_options',
        'popup-advertisement-settings',
        'popup_advertisement_settings_page',
        'dashicons-megaphone'
    );
}

// Create the settings page
function popup_advertisement_settings_page() {
    ?>
    <div class="wrap">
        <h1>Popup Advertisement Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('popup_advertisement_options');
            do_settings_sections('popup-advertisement-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register the settings
add_action('admin_init', 'popup_advertisement_settings');

function popup_advertisement_settings() {
    register_setting('popup_advertisement_options', 'popup_advertisement_image');
    register_setting('popup_advertisement_options', 'popup_advertisement_enabled');

    add_settings_section(
        'popup_advertisement_section',
        'Settings',
        'popup_advertisement_section_callback',
        'popup-advertisement-settings'
    );

    add_settings_field(
        'popup_advertisement_image',
        'Advertisement Image',
        'popup_advertisement_image_callback',
        'popup-advertisement-settings',
        'popup_advertisement_section'
    );

    add_settings_field(
        'popup_advertisement_enabled',
        'Enable Popup',
        'popup_advertisement_enabled_callback',
        'popup-advertisement-settings',
        'popup_advertisement_section'
    );
}

// Section callback
function popup_advertisement_section_callback() {
    echo 'Configure the popup advertisement settings.';
}

// Image callback
function popup_advertisement_image_callback() {
    $image = get_option('popup_advertisement_image');
    echo '<input type="text" id="popup_advertisement_image" name="popup_advertisement_image" value="' . esc_attr($image) . '" />_';
    echo '<input type="button" id="upload_image_button" class="button" value="Upload Image" />_';
    echo '<p class="description">Upload the image for the advertisement.</p>_';
}

// Enabled callback
function popup_advertisement_enabled_callback() {
    $enabled = get_option('popup_advertisement_enabled');
    echo '<input type="checkbox" id="popup_advertisement_enabled" name="popup_advertisement_enabled" value="1" ' . checked(1, $enabled, false) . ' />';
}

// Enqueue scripts
add_action('admin_enqueue_scripts', 'popup_advertisement_enqueue_scripts');

function popup_advertisement_enqueue_scripts($hook) {
    if ($hook != 'toplevel_page_popup-advertisement-settings') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('popup-advertisement-admin', plugin_dir_url(__FILE__) . 'admin.js', array('jquery'), '1.0', true);
}

// Enqueue frontend scripts and styles
add_action('wp_enqueue_scripts', 'popup_advertisement_frontend_scripts');

function popup_advertisement_frontend_scripts() {
    if (is_front_page() && get_option('popup_advertisement_enabled')) {
        wp_enqueue_style('popup-advertisement', plugin_dir_url(__FILE__) . 'popup.css');
        wp_enqueue_script('popup-advertisement', plugin_dir_url(__FILE__) . 'popup.js', array('jquery'), '1.0', true);

        $image_url = get_option('popup_advertisement_image');
        wp_localize_script('popup-advertisement', 'popup_advertisement_data', array('image_url' => $image_url));
    }
}

// Add the popup to the footer
add_action('wp_footer', 'popup_advertisement_display_popup');

function popup_advertisement_display_popup() {
    if (is_front_page() && get_option('popup_advertisement_enabled')) {
        $image_url = get_option('popup_advertisement_image');
        if ($image_url) {
            ?>
            <div id="popup-advertisement">
                <div class="popup-content">
                    <span class="close-button">&times;</span>
                    <img src="<?php echo esc_url($image_url); ?>" alt="Advertisement" />
                </div>
            </div>
            <?php
        }
    }
}

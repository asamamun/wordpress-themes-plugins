jQuery(document).ready(function($) {
    // Function to set a cookie
    function setCookie(name, value, hours) {
        var expires = "";
        if (hours) {
            var date = new Date();
            date.setTime(date.getTime() + (hours * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "")  + expires + "; path=/";
    }

    // Function to get a cookie
    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for(var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    // Get the current image URL from the localized data
    var current_image_url = popup_advertisement_data.image_url;

    // Get the image URL from the cookie
    var cookie_image_url = getCookie('popup_advertisement_image_url');

    // Check if the cookie exists and if the image URL is the same
    if (getCookie('popup_advertisement_shown') != 'true' || current_image_url !== cookie_image_url) {
        // Show the popup
        $('#popup-advertisement').fadeIn();
        setCookie('popup_advertisement_shown', 'true', 12);
        setCookie('popup_advertisement_image_url', current_image_url, 12);
    }

    // Hide the popup when the close button is clicked
    $('#popup-advertisement .close-button').click(function() {
        $('#popup-advertisement').fadeOut();
    });

    // Hide the popup when clicking outside the content
    $('#popup-advertisement').click(function(e) {
        if (e.target.id == 'popup-advertisement') {
            $(this).fadeOut();
        }
    });
});
<?php
/**
 * Plugin Name: WTTR Weather Widget
 * Description: Shows current weather for selected city using wttr.in (no API key needed).
 * Version: 1.0
 * Author: Your Name
 */

class WTTR_Weather_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'wttr_weather_widget',
            __('WTTR Weather Widget', 'text_domain'),
            array('description' => __('Displays weather using wttr.in API (no key needed)', 'text_domain'))
        );
    }

    public function widget($args, $instance) {
        $city = !empty($instance['city']) ? $instance['city'] : 'Dhaka';
        $city_url = urlencode($city);
        $response = wp_remote_get("https://wttr.in/{$city_url}?format=j1");

        echo $args['before_widget'];
        echo $args['before_title'] . esc_html("Weather in $city") . $args['after_title'];

        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($data['current_condition'][0])) {
                $condition = $data['current_condition'][0];
                $temp = $condition['temp_C'];
                $desc = $condition['weatherDesc'][0]['value'];
                echo "<p><strong>{$temp}°C</strong>, {$desc}</p>";
            } else {
                echo "<p>Weather data not available.</p>";
            }
        } else {
            echo "<p>Unable to fetch weather.</p>";
        }

        echo $args['after_widget'];
    }

    public function form($instance) {
        $selected_city = !empty($instance['city']) ? $instance['city'] : 'Dhaka';
        $cities = ['Dhaka', 'Tokyo', 'New York'];
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('city')); ?>">Select City:</label>
            <select name="<?php echo esc_attr($this->get_field_name('city')); ?>" class="widefat">
                <?php foreach ($cities as $city): ?>
                    <option value="<?php echo esc_attr($city); ?>" <?php selected($selected_city, $city); ?>>
                        <?php echo esc_html($city); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['city'] = sanitize_text_field($new_instance['city']);
        return $instance;
    }
}

function register_wttr_weather_widget() {
    register_widget('WTTR_Weather_Widget');
}
add_action('widgets_init', 'register_wttr_weather_widget');

<?php
/**
 * Plugin Name: Smart Weather Widget (AJAX+Icons+Units)
 * Description: Weather widget with AJAX, icons, C/F toggle, and API selector.
 * Version: 1.2
 * Author: ASA Al-Mamun
 */
class Smart_Weather_Widget extends WP_Widget {

    private $cities = [
        'Dhaka' => ['lat' => 23.8103, 'lon' => 90.4125],
        'Tokyo' => ['lat' => 35.6895, 'lon' => 139.6917],
        'New York' => ['lat' => 40.7128, 'lon' => -74.0060],
        'London' => ['lat' => 51.5074, 'lon' => -0.1278],
        'Sydney' => ['lat' => -33.8688, 'lon' => 151.2093],
        'Berlin' => ['lat' => 52.5200, 'lon' => 13.4050],
        'Paris' => ['lat' => 48.8566, 'lon' => 2.3522],
        'Moscow' => ['lat' => 55.7558, 'lon' => 37.6173],
        'Beijing' => ['lat' => 39.9042, 'lon' => 116.4074],
        'Cairo' => ['lat' => 30.0444, 'lon' => 31.2357],
        'Rio de Janeiro' => ['lat' => -22.9068, 'lon' => -43.1729],
        'Cape Town' => ['lat' => -33.9249, 'lon' => 18.4241],
        'Mumbai' => ['lat' => 19.0760, 'lon' => 72.8777],
        'Los Angeles' => ['lat' => 34.0522, 'lon' => -118.2437],
        'Toronto' => ['lat' => 43.6511, 'lon' => -79.3470],
        'Singapore' => ['lat' => 1.3521, 'lon' => 103.8198],
        'Istanbul' => ['lat' => 41.0082, 'lon' => 28.9784],
        'Bangkok' => ['lat' => 13.7563, 'lon' => 100.5018],
        'Buenos Aires' => ['lat' => -34.6037, 'lon' => -58.3816],
        'Kuala Lumpur' => ['lat' => 3.139, 'lon' => 101.6869],
        'Sao Paulo' => ['lat' => -23.5505, 'lon' => -46.6333],
        'Madrid' => ['lat' => 40.4168, 'lon' => -3.7038],
        'Barcelona' => ['lat' => 41.3851, 'lon' => 2.1734],
        'Amsterdam' => ['lat' => 52.3676, 'lon' => 4.9041],
        'Seoul' => ['lat' => 37.5665, 'lon' => 126.9780],
        'Hong Kong' => ['lat' => 22.3964, 'lon' => 114.1095],
        'Dubai' => ['lat' => 25.276987, 'lon' => 55.296249],
        'Lagos' => ['lat' => 6.5244, 'lon' => 3.3792],
        'Nairobi' => ['lat' => -1.286389, 'lon' => 36.817223],
        'Lima' => ['lat' => -12.0464, 'lon' => -77.0428],
        'Santiago' => ['lat' => -33.4489, 'lon' => -70.6693],
        'Athens' => ['lat' => 37.9838, 'lon' => 23.7275],
        'Lisbon' => ['lat' => 38.7223, 'lon' => -9.1393],
        'Prague' => ['lat' => 50.0755, 'lon' => 14.4378],
    ];


    private $apis = ['open-meteo', 'wttr'];

    public function __construct() {
        parent::__construct(
            'smart_weather_widget',
            __('Smart Weather Widget (Full)', 'text_domain'),
            ['description' => __('AJAX weather with icons, toggle, API selection.', 'text_domain')]
        );

        add_action('wp_ajax_get_weather_data', [$this, 'ajax_handler']);
        add_action('wp_ajax_nopriv_get_weather_data', [$this, 'ajax_handler']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_script']);
    }

    public function enqueue_script() {
        wp_enqueue_script('smart-weather-js', plugin_dir_url(__FILE__) . 'smart-weather.js', ['jquery'], null, true);
        wp_localize_script('smart-weather-js', 'smartWeatherAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('smart_weather_nonce'),
        ]);
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        echo $args['before_title'] . esc_html("Smart Weather Widget") . $args['after_title'];
        ?>

        <form id="smart-weather-form">
            <p>
                <label class="form-label">API:</label>
                <select name="weather_api" class="widefat form-select" id="weather_api">
                    <?php foreach ($this->apis as $api): ?>
                        <option value="<?php echo esc_attr($api); ?>">
                            <?php echo esc_html(ucwords(str_replace('-', ' ', $api))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p>
                <label class="form-label">City:</label>
                <select name="weather_city" class="widefat form-select" id="weather_city">
                    <?php foreach ($this->cities as $city => $coords): ?>
                        <option value="<?php echo esc_attr($city); ?>">
                            <?php echo esc_html($city); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p>
                <label class="form-label">Units:</label>
                <select name="units" class="widefat form-select" id="units">
                    <option value="C">Celsius</option>
                    <option value="F">Fahrenheit</option>
                </select>
            </p>

            <p><button type="submit" class="btn btn-outline-info">Get Weather</button></p>
        </form>

        <div id="weather-result" style="margin-top: 10px; font-family: sans-serif;"></div>

        <?php
        echo $args['after_widget'];
    }

    public function ajax_handler() {
        check_ajax_referer('smart_weather_nonce', 'nonce');

        $api  = sanitize_text_field($_POST['weather_api']);
        $city = sanitize_text_field($_POST['weather_city']);
        $unit = sanitize_text_field($_POST['units']);

        if (!isset($this->cities[$city])) {
            wp_send_json_error('Invalid city');
        }

        $coords = $this->cities[$city];

        if ($api === 'open-meteo') {
            $url = "https://api.open-meteo.com/v1/forecast?latitude={$coords['lat']}&longitude={$coords['lon']}&current_weather=true";
            $response = wp_remote_get($url);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['current_weather'])) {
                    $weather = $data['current_weather'];
                    $tempC = $weather['temperature'];
                    $temp = ($unit === 'F') ? round(($tempC * 9/5) + 32, 1) : $tempC;
                    $icon = $this->get_icon($weather['weathercode'], 'open-meteo');
                    $wind = $weather['windspeed'];
                    $unit_display = $unit === 'F' ? '°F' : '°C';
                    wp_send_json_success("<p>{$icon} <strong>{$temp}{$unit_display}</strong>, Wind: {$wind} km/h</p>");
                }
            }
            wp_send_json_error('Failed to fetch from Open-Meteo');
        }

        if ($api === 'wttr') {
            $url = "https://wttr.in/" . urlencode($city) . "?format=j1";
            $response = wp_remote_get($url);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['current_condition'][0])) {
                    $weather = $data['current_condition'][0];
                    $tempC = $weather['temp_C'];
                    $desc = $weather['weatherDesc'][0]['value'];
                    $temp = ($unit === 'F') ? round(($tempC * 9/5) + 32, 1) : $tempC;
                    $unit_display = $unit === 'F' ? '°F' : '°C';
                    $icon = $this->get_icon($desc, 'wttr');
                    wp_send_json_success("<p>{$icon} <strong>{$temp}{$unit_display}</strong>, {$desc}</p>");
                }
            }
            wp_send_json_error('Failed to fetch from wttr.in');
        }

        wp_send_json_error('Unsupported API');
    }

    private function get_icon($code_or_desc, $source) {
        // Open-Meteo weather codes: https://open-meteo.com/en/docs#weathervariables
        if ($source === 'open-meteo') {
            $icons = [
                0 => '☀️',     // Clear
                1 => '🌤️',    // Mainly clear
                2 => '⛅',     // Partly cloudy
                3 => '☁️',     // Overcast
                45 => '🌫️',   // Fog
                48 => '🌫️',   // Depositing rime fog
                51 => '🌦️',   // Drizzle
                61 => '🌧️',   // Rain
                71 => '❄️',    // Snow
                95 => '⛈️',    // Thunderstorm
            ];
            return $icons[$code_or_desc] ?? '🌈';
        }

        if ($source === 'wttr') {
            $desc = strtolower($code_or_desc);
            if (strpos($desc, 'sun') !== false) return '☀️';
            if (strpos($desc, 'cloud') !== false) return '☁️';
            if (strpos($desc, 'rain') !== false) return '🌧️';
            if (strpos($desc, 'snow') !== false) return '❄️';
            if (strpos($desc, 'storm') !== false) return '⛈️';
            if (strpos($desc, 'fog') !== false) return '🌫️';
            return '🌈';
        }

        return '❓';
    }

    public function form($instance) {
        echo '<p>This widget supports icons, C/F toggle, and API selection via AJAX.</p>';
    }

    public function update($new_instance, $old_instance) {
        return $old_instance;
    }
}

function register_smart_weather_widget() {
    register_widget('Smart_Weather_Widget');
}
add_action('widgets_init', 'register_smart_weather_widget');


//this is the AJAX version of the widget
 /*
class Smart_Weather_Widget extends WP_Widget {

    private $cities = [
        'Dhaka' => ['lat' => 23.8103, 'lon' => 90.4125],
        'Tokyo' => ['lat' => 35.6895, 'lon' => 139.6917],
        'New York' => ['lat' => 40.7128, 'lon' => -74.0060],
        'London' => ['lat' => 51.5074, 'lon' => -0.1278],
        'Sydney' => ['lat' => -33.8688, 'lon' => 151.2093],
        'Berlin' => ['lat' => 52.5200, 'lon' => 13.4050],
        'Paris' => ['lat' => 48.8566, 'lon' => 2.3522],
        'Moscow' => ['lat' => 55.7558, 'lon' => 37.6173],
        'Beijing' => ['lat' => 39.9042, 'lon' => 116.4074],
        'Cairo' => ['lat' => 30.0444, 'lon' => 31.2357],
        'Rio de Janeiro' => ['lat' => -22.9068, 'lon' => -43.1729],
        'Cape Town' => ['lat' => -33.9249, 'lon' => 18.4241],
        'Mumbai' => ['lat' => 19.0760, 'lon' => 72.8777],
        'Los Angeles' => ['lat' => 34.0522, 'lon' => -118.2437],
        'Toronto' => ['lat' => 43.6511, 'lon' => -79.3470],
        'Singapore' => ['lat' => 1.3521, 'lon' => 103.8198],
        'Istanbul' => ['lat' => 41.0082, 'lon' => 28.9784],
        'Bangkok' => ['lat' => 13.7563, 'lon' => 100.5018],
        'Buenos Aires' => ['lat' => -34.6037, 'lon' => -58.3816],
        'Kuala Lumpur' => ['lat' => 3.139, 'lon' => 101.6869],
        'Sao Paulo' => ['lat' => -23.5505, 'lon' => -46.6333],
        'Madrid' => ['lat' => 40.4168, 'lon' => -3.7038],
        'Barcelona' => ['lat' => 41.3851, 'lon' => 2.1734],
        'Amsterdam' => ['lat' => 52.3676, 'lon' => 4.9041],
        'Seoul' => ['lat' => 37.5665, 'lon' => 126.9780],
        'Hong Kong' => ['lat' => 22.3964, 'lon' => 114.1095],
        'Dubai' => ['lat' => 25.276987, 'lon' => 55.296249],
        'Lagos' => ['lat' => 6.5244, 'lon' => 3.3792],
        'Nairobi' => ['lat' => -1.286389, 'lon' => 36.817223],
        'Lima' => ['lat' => -12.0464, 'lon' => -77.0428],
        'Santiago' => ['lat' => -33.4489, 'lon' => -70.6693],
        'Athens' => ['lat' => 37.9838, 'lon' => 23.7275],
        'Lisbon' => ['lat' => 38.7223, 'lon' => -9.1393],
        'Prague' => ['lat' => 50.0755, 'lon' => 14.4378],
    ];

    private $apis = ['open-meteo', 'wttr'];

    public function __construct() {
        parent::__construct(
            'smart_weather_widget',
            __('Smart Weather Widget (AJAX)', 'text_domain'),
            array('description' => __('Weather with API and city dropdowns using AJAX.', 'text_domain'))
        );

        // Register AJAX handlers
        add_action('wp_ajax_get_weather_data', [$this, 'ajax_handler']);
        add_action('wp_ajax_nopriv_get_weather_data', [$this, 'ajax_handler']);

        // Enqueue JS
        add_action('wp_enqueue_scripts', [$this, 'enqueue_script']);
    }

    public function enqueue_script() {
        wp_enqueue_script('smart-weather-js', plugin_dir_url(__FILE__) . 'smart-weather.js', ['jquery'], null, true);
        wp_localize_script('smart-weather-js', 'smartWeatherAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('smart_weather_nonce'),
        ]);
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        echo $args['before_title'] . esc_html("Smart Weather Widget") . $args['after_title'];
        ?>

        <form id="smart-weather-form">
            <p>
                <label for="weather_api" class="form-label">Select API:</label>
                <select name="weather_api" class="widefat form-select" id="weather_api">
                    <?php foreach ($this->apis as $api): ?>
                        <option value="<?php echo esc_attr($api); ?>">
                            <?php echo esc_html(ucwords(str_replace('-', ' ', $api))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p>
                <label for="weather_city" class="form-label">Select City:</label>
                <select name="weather_city" class="widefat form-select" id="weather_city">
                    <?php foreach ($this->cities as $city => $coords): ?>
                        <option value="<?php echo esc_attr($city); ?>">
                            <?php echo esc_html($city); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p><button type="submit" class="button btn btn-outline-info">Get Weather</button></p>
        </form>

        <div id="weather-result" style="margin-top: 10px;"></div>

        <?php
        echo $args['after_widget'];
    }

    public function ajax_handler() {
        check_ajax_referer('smart_weather_nonce', 'nonce');

        $api  = sanitize_text_field($_POST['weather_api']);
        $city = sanitize_text_field($_POST['weather_city']);

        $cities = $this->cities;

        if (!isset($cities[$city])) {
            wp_send_json_error('Invalid city');
        }

        $coords = $cities[$city];

        if ($api === 'open-meteo') {
            $url = "https://api.open-meteo.com/v1/forecast?latitude={$coords['lat']}&longitude={$coords['lon']}&current_weather=true";
            $response = wp_remote_get($url);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['current_weather'])) {
                    $temp = $data['current_weather']['temperature'];
                    $wind = $data['current_weather']['windspeed'];
                    wp_send_json_success("<p><strong>{$temp}°C</strong>, Wind: {$wind} km/h (Open-Meteo)</p>");
                }
            }
            wp_send_json_error('Failed to fetch from Open-Meteo');
        }

        if ($api === 'wttr') {
            $url = "https://wttr.in/" . urlencode($city) . "?format=j1";
            $response = wp_remote_get($url);
            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['current_condition'][0])) {
                    $weather = $data['current_condition'][0];
                    $temp = $weather['temp_C'];
                    $desc = $weather['weatherDesc'][0]['value'];
                    wp_send_json_success("<p><strong>{$temp}°C</strong>, {$desc} (wttr.in)</p>");
                }
            }
            wp_send_json_error('Failed to fetch from wttr.in');
        }

        wp_send_json_error('Unsupported API');
    }

    public function form($instance) {
        echo '<p>This widget uses AJAX to load weather based on selected API and city.</p>';
    }

    public function update($new_instance, $old_instance) {
        return $old_instance;
    }
}

function register_smart_weather_widget() {
    register_widget('Smart_Weather_Widget');
}
add_action('widgets_init', 'register_smart_weather_widget');

*/

// Uncomment the following lines to use the non-AJAX version of the widget

/* class Smart_Weather_Widget extends WP_Widget {

    private $cities = [
        'Dhaka' => ['lat' => 23.8103, 'lon' => 90.4125],
        'Tokyo' => ['lat' => 35.6895, 'lon' => 139.6917],
        'New York' => ['lat' => 40.7128, 'lon' => -74.0060],
        'London' => ['lat' => 51.5074, 'lon' => -0.1278],
        'Sydney' => ['lat' => -33.8688, 'lon' => 151.2093],
        'Berlin' => ['lat' => 52.5200, 'lon' => 13.4050],
        'Paris' => ['lat' => 48.8566, 'lon' => 2.3522],
        'Moscow' => ['lat' => 55.7558, 'lon' => 37.6173],
        'Beijing' => ['lat' => 39.9042, 'lon' => 116.4074],
        'Cairo' => ['lat' => 30.0444, 'lon' => 31.2357],
        'Rio de Janeiro' => ['lat' => -22.9068, 'lon' => -43.1729],
        'Cape Town' => ['lat' => -33.9249, 'lon' => 18.4241],
        'Mumbai' => ['lat' => 19.0760, 'lon' => 72.8777],
        'Los Angeles' => ['lat' => 34.0522, 'lon' => -118.2437],
        'Toronto' => ['lat' => 43.6511, 'lon' => -79.3470],
        'Singapore' => ['lat' => 1.3521, 'lon' => 103.8198],
        'Istanbul' => ['lat' => 41.0082, 'lon' => 28.9784],
        'Bangkok' => ['lat' => 13.7563, 'lon' => 100.5018],
        'Buenos Aires' => ['lat' => -34.6037, 'lon' => -58.3816],
        'Kuala Lumpur' => ['lat' => 3.139, 'lon' => 101.6869],
        'Sao Paulo' => ['lat' => -23.5505, 'lon' => -46.6333],
        'Madrid' => ['lat' => 40.4168, 'lon' => -3.7038],
        'Barcelona' => ['lat' => 41.3851, 'lon' => 2.1734],
        'Amsterdam' => ['lat' => 52.3676, 'lon' => 4.9041],
        'Seoul' => ['lat' => 37.5665, 'lon' => 126.9780],
        'Hong Kong' => ['lat' => 22.3964, 'lon' => 114.1095],
        'Dubai' => ['lat' => 25.276987, 'lon' => 55.296249],
        'Lagos' => ['lat' => 6.5244, 'lon' => 3.3792],
        'Nairobi' => ['lat' => -1.286389, 'lon' => 36.817223],
        'Lima' => ['lat' => -12.0464, 'lon' => -77.0428],
        'Santiago' => ['lat' => -33.4489, 'lon' => -70.6693],
        'Athens' => ['lat' => 37.9838, 'lon' => 23.7275],
        'Lisbon' => ['lat' => 38.7223, 'lon' => -9.1393],
        'Prague' => ['lat' => 50.0755, 'lon' => 14.4378],
    ];

    private $apis = ['open-meteo', 'wttr'];

    public function __construct() {
        parent::__construct(
            'smart_weather_widget',
            __('Smart Weather Widget', 'text_domain'),
            array('description' => __('Choose weather API and city to view current weather.', 'text_domain'))
        );
    }

    public function widget($args, $instance) {
        $selected_api = !empty($_POST['weather_api']) ? sanitize_text_field($_POST['weather_api']) : '';
        $selected_city = !empty($_POST['weather_city']) ? sanitize_text_field($_POST['weather_city']) : '';

        echo $args['before_widget'];
        echo $args['before_title'] . esc_html("Smart Weather Widget") . $args['after_title'];
        ?>

        <form method="post">
            <p>
                <label for="weather_api" class="form-label">Select API:</label>
                <select name="weather_api" id="weather_api" class="widefat form-select">
                    <?php foreach ($this->apis as $api): ?>
                        <option value="<?php echo esc_attr($api); ?>" <?php selected($selected_api, $api); ?>>
                            <?php echo esc_html(ucwords(str_replace('-', ' ', $api))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p>
                <label for="weather_city" class="form-label">Select City:</label>
                <select name="weather_city" id="weather_city" class="widefat form-select">
                    <?php foreach ($this->cities as $city => $coords): ?>
                        <option value="<?php echo esc_attr($city); ?>" <?php selected($selected_city, $city); ?>>
                            <?php echo esc_html($city); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p><input type="submit" class="button btn btn-outline-info" value="Get Weather"></p>
        </form>

        <?php
        // If form is submitted and valid inputs
        if ($selected_api && $selected_city) {
            echo '<div style="margin-top: 10px;">';
            $this->show_weather($selected_api, $selected_city);
            echo '</div>';
        }

        echo $args['after_widget'];
    }

    private function show_weather($api, $city) {
        if (!isset($this->cities[$city])) {
            echo "<p>Invalid city selected.</p>";
            return;
        }

        $coords = $this->cities[$city];

        if ($api === 'open-meteo') {
            $url = "https://api.open-meteo.com/v1/forecast?latitude={$coords['lat']}&longitude={$coords['lon']}&current_weather=true";
            $response = wp_remote_get($url);

            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['current_weather'])) {
                    $temp = $data['current_weather']['temperature'];
                    $wind = $data['current_weather']['windspeed'];
                    echo "<p><strong>{$temp}°C</strong>, Wind: {$wind} km/h (Open-Meteo)</p>";
                } else {
                    echo "<p>No data available from Open-Meteo.</p>";
                }
            } else {
                echo "<p>Failed to fetch data from Open-Meteo.</p>";
            }

        } elseif ($api === 'wttr') {
            $url = "https://wttr.in/" . urlencode($city) . "?format=j1";
            $response = wp_remote_get($url);

            if (!is_wp_error($response)) {
                $data = json_decode(wp_remote_retrieve_body($response), true);
                if (isset($data['current_condition'][0])) {
                    $weather = $data['current_condition'][0];
                    $temp = $weather['temp_C'];
                    $desc = $weather['weatherDesc'][0]['value'];
                    echo "<p><strong>{$temp}°C</strong>, {$desc} (wttr.in)</p>";
                } else {
                    echo "<p>No data available from wttr.in.</p>";
                }
            } else {
                echo "<p>Failed to fetch data from wttr.in.</p>";
            }

        } else {
            echo "<p>Unsupported API selected.</p>";
        }
    }

    public function form($instance) {
        echo '<p>This widget lets users choose a weather API and city.</p>';
    }

    public function update($new_instance, $old_instance) {
        return $old_instance; // No settings to save
    }
}

function register_smart_weather_widget() {
    register_widget('Smart_Weather_Widget');
}
add_action('widgets_init', 'register_smart_weather_widget'); */

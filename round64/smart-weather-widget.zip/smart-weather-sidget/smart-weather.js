jQuery(document).ready(function($) {
    $('#smart-weather-form').on('submit', function(e) {
        e.preventDefault();
        let api = $('select[name="weather_api"]').val();
        let city = $('select[name="weather_city"]').val();

        $('#weather-result').html('Loading...');

        $.post(smartWeatherAjax.ajax_url, {
            action: 'get_weather_data',
            weather_api: api,
            weather_city: city,
            nonce: smartWeatherAjax.nonce
        }, function(response) {
            if (response.success) {
                console.log(response);
                $('#weather-result').html(response.data);
            } else {
                $('#weather-result').html('<p>Error: ' + response.data + '</p>');
            }
        });
    });
});

<?php
/**
 * Plugin Name: Simple Weather Widget
 * Description: A weather widget with a city dropdown (Dhaka, Tokyo, New York).
 * Version: 1.0
 * Author: Your Name
 */

class Simple_Weather_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'simple_weather_widget',
            __('Simple Weather Widget', 'text_domain'),
            array('description' => __('Shows weather for selected city.', 'text_domain'))
        );
    }

    public function widget($args, $instance) {
        $city = !empty($instance['city']) ? $instance['city'] : 'Dhaka';
        $api_key = 'YOUR_API_KEY_HERE'; // Replace with your OpenWeatherMap API key

        $response = wp_remote_get("https://api.openweathermap.org/data/2.5/weather?q={$city}&appid={$api_key}&units=metric");

        echo $args['before_widget'];
        echo $args['before_title'] . 'Weather in ' . esc_html($city) . $args['after_title'];

        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if ($data && isset($data['main']['temp'])) {
                $temp = $data['main']['temp'];
                $desc = $data['weather'][0]['description'];
                echo "<p><strong>{$temp}°C</strong>, {$desc}</p>";
            } else {
                echo "<p>Weather data not available.</p>";
            }
        } else {
            echo "<p>Unable to fetch weather.</p>";
        }

        echo $args['after_widget'];
    }

    public function form($instance) {
        $selected_city = !empty($instance['city']) ? $instance['city'] : 'Dhaka';
        $cities = ['Dhaka', 'Tokyo', 'New York'];
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('city')); ?>">Select City:</label>
            <select name="<?php echo esc_attr($this->get_field_name('city')); ?>" class="widefat">
                <?php foreach ($cities as $city): ?>
                    <option value="<?php echo esc_attr($city); ?>" <?php selected($selected_city, $city); ?>>
                        <?php echo esc_html($city); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['city'] = sanitize_text_field($new_instance['city']);
        return $instance;
    }
}

function register_simple_weather_widget() {
    register_widget('Simple_Weather_Widget');
}
add_action('widgets_init', 'register_simple_weather_widget');

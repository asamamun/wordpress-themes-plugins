<?php
function custom_theme_widgets_init() {

    // Sidebar Widget Area
    register_sidebar(array(
        'name'          => __('Sidebar', 'your-theme-textdomain'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here for the sidebar.', 'your-theme-textdomain'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    // Footer Widget Area
    register_sidebar(array(
        'name'          => __('FooterLeft', 'your-theme-textdomain'),
        'id'            => 'footer-left',
        'description'   => __('Add widgets here for the footer.', 'your-theme-textdomain'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    register_sidebar(array(
        'name'          => __('FooterMiddle', 'your-theme-textdomain'),
        'id'            => 'footer-middle',
        'description'   => __('Add widgets here for the footer.', 'your-theme-textdomain'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    register_sidebar(array(
        'name'          => __('FooterRight', 'your-theme-textdomain'),
        'id'            => 'footer-right',
        'description'   => __('Add widgets here for the footer.', 'your-theme-textdomain'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'custom_theme_widgets_init');

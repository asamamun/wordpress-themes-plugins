<h3>popular AI links</h3>
<ul>
    <li><a href="https://www.openai.com/">openai</a></li>
    <li><a href="https://github.com/openai/gpt-3-5-turbo">gpt-3-5-turbo</a></li>
    <li><a href="https://platform.openai.com/docs/guides/gpt/gpt-4">gpt-4</a></li>
</ul>
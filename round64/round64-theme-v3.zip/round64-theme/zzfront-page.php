<?php get_header(); ?>
<?php get_template_part('components/ailinks'); ?>


<?php get_footer(); ?>

<?php
// Add Theme Customizer settings for Post Title Styling
function mytheme_post_styling_customize_register($wp_customize) {
    // Add a section for post styling
    $wp_customize->add_section('mytheme_post_styling_section', array(
        'title' => __('Post Styling', 'mytheme'),
        'priority' => 35, // Place after Carousel Settings (priority 30)
    ));

    // Title color setting
    $wp_customize->add_setting('mytheme_post_title_color', array(
        'default' => '#000000', // Default black
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'mytheme_post_title_color', array(
        'label' => __('Post Title Color', 'mytheme'),
        'section' => 'mytheme_post_styling_section',
        'settings' => 'mytheme_post_title_color',
    )));

    // Title background color setting
    $wp_customize->add_setting('mytheme_post_title_background_color', array(
        'default' => '#ffffff', // Default white
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'mytheme_post_title_background_color', array(
        'label' => __('Post Title Background Color', 'mytheme'),
        'section' => 'mytheme_post_styling_section',
        'settings' => 'mytheme_post_title_background_color',
    )));
}
add_action('customize_register', 'mytheme_post_styling_customize_register');

// Enqueue Bootstrap 5.3 CSS and JS (unchanged, included for completeness if needed elsewhere)
function mytheme_enqueue_scripts() {
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', [], '5.3.0');
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', ['jquery'], '5.3.0', true);
}
// add_action('wp_enqueue_scripts', 'mytheme_enqueue_scripts');
?>
<!-- footer start -->
    <div class="row position-relative">
      <div class="col-4">
        <?php if (is_active_sidebar('footer-left')) : ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar('footer-left'); ?>
    </aside>
<?php endif; ?> 
      </div>
      <div class="col-4">
<?php if (is_active_sidebar('footer-middle')) : ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar('footer-middle'); ?>
    </aside>
<?php endif; ?> 

      </div>
      <div class="col-4">
        <?php if ( has_nav_menu( 'footer-menu' ) ) : ?>
      <?php  
        // if footer menu available show footer-menu

      wp_nav_menu([
        'theme_location' => 'footer-menu',
        'container' => false,
        'depth' => 2,
        'menu_class' => '',
        'fallback_cb' => '_',        
      ]);
      ?>
      <?php endif; ?>
      <hr>
      <?php if (is_active_sidebar('footer-right')) : ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar('footer-right'); ?>
    </aside>
<?php endif; ?> 
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        @all rights reserved <?= date("Y") ?>
      </div>
    </div>
    <!-- footer end -->
  </div>
  <?php wp_footer(); ?>
</body>

</html>
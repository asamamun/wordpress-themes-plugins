<h2>Sidebar</h2>
        <?php
      wp_nav_menu([
        'theme_location' => 'sidebar-menu',
        'container' => false,
        'depth' => 2,
        'menu_class' => '',
        'fallback_cb' => '_',        
      ]);
      ?>
<hr>
<?php if (is_active_sidebar('sidebar-1')) : ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar('sidebar-1'); ?>
    </aside>
<?php endif; ?>      
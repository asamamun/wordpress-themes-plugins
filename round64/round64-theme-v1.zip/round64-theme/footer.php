<!-- footer start -->
    <div class="row position-relative">
      <div class="col-4">left</div>
      <div class="col-4">middle</div>
      <div class="col-4">
        <?php
      wp_nav_menu([
        'theme_location' => 'footer-menu',
        'container' => false,
        'depth' => 2,
        'menu_class' => '',
        'fallback_cb' => '_',        
      ]);
      ?>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        @all rights reserved <?= date("Y") ?>
      </div>
    </div>
    <!-- footer end -->
  </div>
</body>

</html>
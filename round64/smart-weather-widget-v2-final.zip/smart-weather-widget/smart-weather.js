jQuery(document).ready(function($) {
    $('#smart-weather-form').on('submit', function(e) {
        e.preventDefault();

        let api = $('select[name="weather_api"]').val();
        let city = $('select[name="weather_city"]').val();
        let units = $('input[name="units"]:checked').val() || 'C'; // ✅ Define this!
        let cache_time = $('input[name="cache_time"]').val() || 300;

        $('#weather-result').html('Loading...');

        $.post(smartWeatherAjax.ajax_url, {
            action: 'get_weather_data',
            weather_api: api,
            weather_city: city,
            units: units,
            cache_time: cache_time,
            nonce: smartWeatherAjax.nonce
        }, function(response) {
            if (response.success) {
                console.log(response);
                $('#weather-result').html(response.data);
            } else {
                $('#weather-result').html('<p>Error: ' + response.data + '</p>');
            }
        });
    });
});

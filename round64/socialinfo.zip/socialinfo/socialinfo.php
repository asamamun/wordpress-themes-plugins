<?php
/**
 * Plugin Name: Social Info
 * Description: Adds social media profile fields to user profiles and displays them after posts.
 * Version: 1.2
 * Author: Gemini
 */

function socialinfo_add_contact_methods( $contactmethods ) {
    $contactmethods['facebook'] = 'Facebook';
    $contactmethods['twitter'] = 'Twitter';
    $contactmethods['linkedin'] = 'LinkedIn';
    $contactmethods['github'] = 'GitHub';
    $contactmethods['phone'] = 'Phone';
    return $contactmethods;
}
add_filter( 'user_contactmethods', 'socialinfo_add_contact_methods' );

class Social_Info_Profile_Picture {

    public function __construct() {
        add_action( 'show_user_profile', array( $this, 'add_profile_picture_field' ) );
        add_action( 'edit_user_profile', array( $this, 'add_profile_picture_field' ) );
        add_action( 'personal_options_update', array( $this, 'save_profile_picture_field' ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_profile_picture_field' ) );
        add_action( 'admin_enqueue_scripts', array($this, 'enqueue_media_uploader' ) );
    }

    public function enqueue_media_uploader() {
        wp_enqueue_media();
    }

    public function add_profile_picture_field( $user ) {
        ?>
        <h3><?php _e( 'Profile Picture', 'socialinfo' ); ?></h3>
        <table class="form-table">
            <tr>
                <th><label for="socialinfo_profile_picture"><?php _e( 'Profile Picture', 'socialinfo' ); ?></label></th>
                <td>
                    <input type="text" name="socialinfo_profile_picture" id="socialinfo_profile_picture" value="<?php echo esc_attr( get_the_author_meta( 'socialinfo_profile_picture', $user->ID ) ); ?>" class="regular-text" />
                    <input type='button' class="button-primary" value="<?php _e( 'Upload Image', 'socialinfo' ); ?>" id="uploadimage"/><br />
                    <span class="description"><?php _e( 'Upload a custom profile picture.', 'socialinfo' ); ?></span>
                    <br>
                    <?php if ( get_the_author_meta( 'socialinfo_profile_picture', $user->ID ) ) : ?>
                        <img src="<?php echo esc_url( get_the_author_meta( 'socialinfo_profile_picture', $user->ID ) ); ?>" style="width: 150px; height: 150px; object-fit: cover; border-radius: 50%; margin-top: 10px;">
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('#uploadimage').click(function(e) {
                    e.preventDefault();
                    var image = wp.media({
                        title: 'Upload Image',
                        multiple: false
                    }).open()
                    .on('select', function(e){
                        var uploaded_image = image.state().get('selection').first();
                        var image_url = uploaded_image.toJSON().url;
                        $('#socialinfo_profile_picture').val(image_url);
                    });
                });
            });
        </script>
        <?php
    }

    public function save_profile_picture_field( $user_id ) {
        if ( ! current_user_can( 'edit_user', $user_id ) ) {
            return false;
        }
        if(isset($_POST['socialinfo_profile_picture'])){
            $profile_picture_url = sanitize_text_field($_POST['socialinfo_profile_picture']);
            update_user_meta( $user_id, 'socialinfo_profile_picture', $profile_picture_url );
            error_log("Saving profile picture for user " . $user_id . ": " . $profile_picture_url);
        }
    }
}

new Social_Info_Profile_Picture();

function socialinfo_display_author_info( $content ) {
    if ( is_single() && in_the_loop() && is_main_query() ) {
        // A static variable to track if the info has been added
        static $author_info_added = false;

        if ( ! $author_info_added ) {
            $author_id = get_the_author_meta('ID');
            $profile_picture = get_the_author_meta('socialinfo_profile_picture', $author_id);
            $facebook = get_the_author_meta('facebook', $author_id);
            $twitter = get_the_author_meta('twitter', $author_id);
            $linkedin = get_the_author_meta('linkedin', $author_id);
            $github = get_the_author_meta('github', $author_id);
            $phone = get_the_author_meta('phone', $author_id);

            $author_info = '<div class="author-social-info">';
            if ($profile_picture) {
                $author_info .= '<img src="' . esc_url($profile_picture) . '" style="width: 150px; height: 150px; object-fit: cover; border-radius: 50%; margin-top: 10px;">';
            }
            if ($facebook) {
                $author_info .= '<p>Facebook: ' . esc_url($facebook) . '</p>';
            }
            if ($twitter) {
                $author_info .= '<p>Twitter: ' . esc_url($twitter) . '</p>';
            }
            if ($linkedin) {
                $author_info .= '<p>LinkedIn: ' . esc_url($linkedin) . '</p>';
            }
            if ($github) {
                $author_info .= '<p>GitHub: ' . esc_url($github) . '</p>';
            }
            if ($phone) {
                $author_info .= '<p>Phone: ' . esc_html($phone) . '</p>';
            }
            $author_info .= '</div>';

            $content .= $author_info;
            $author_info_added = true; // Mark as added
        }
    }
    return $content;
}
add_filter( 'the_content', 'socialinfo_display_author_info' );

class Author_Info_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'author_info_widget',
            __('Author Info', 'socialinfo'),
            array( 'description' => __( 'Displays author profile picture and social links.', 'socialinfo' ), )
        );

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
    }

    public function enqueue_styles() {
        wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css' );
        wp_add_inline_style( 'socialinfo-style', '.author-social-info-widget .list-group-item { border: none; padding: 0.5rem 1rem; } .author-social-info-widget .list-group-item a { color: #212529; } .author-social-info-widget .list-group-item a:hover { color: #007bff; }' );
    }

    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }

        if ( is_single() ) {
            global $post;
            $author_id = $post->post_author;
            error_log("Widget - Author ID: " . $author_id);
            $profile_picture = get_the_author_meta('socialinfo_profile_picture', $author_id);
            error_log("Widget - Profile Picture: " . $profile_picture);
            $facebook = get_the_author_meta('facebook', $author_id);
            error_log("Widget - Facebook: " . $facebook);
            $twitter = get_the_author_meta('twitter', $author_id);
            error_log("Widget - Twitter: " . $twitter);
            $linkedin = get_the_author_meta('linkedin', $author_id);
            error_log("Widget - LinkedIn: " . $linkedin);
            $github = get_the_author_meta('github', $author_id);
            error_log("Widget - GitHub: " . $github);
            $phone = get_the_author_meta('phone', $author_id);
            error_log("Widget - Phone: " . $phone);

            echo '<div class="author-social-info-widget text-center">';
            if ($profile_picture) {
                echo '<img src="' . esc_url($profile_picture) . '" class="img-fluid rounded-circle mx-auto d-block mb-3" style="width: 150px; height: 150px; object-fit: cover;">';
            } else {
                // Placeholder for profile picture if none exists
                echo '<div class="img-fluid rounded-circle mx-auto d-block mb-3 bg-light d-flex align-items-center justify-content-center" style="width: 150px; height: 150px; object-fit: cover;"><i class="fas fa-user fa-3x text-muted"></i></div>';
            }
            
            echo '<ul class="list-group list-group-flush">';
            if ($facebook) {
                echo '<li class="list-group-item"><a href="' . esc_url($facebook) . '" target="_blank" class="text-decoration-none"><i class="fab fa-facebook-f me-2"></i>Facebook</a></li>';
            } else {
                echo '<li class="list-group-item text-muted"><i class="fab fa-facebook-f me-2"></i>Facebook (Not Set)</li>';
            }
            if ($twitter) {
                echo '<li class="list-group-item"><a href="' . esc_url($twitter) . '" target="_blank" class="text-decoration-none"><i class="fab fa-twitter me-2"></i>Twitter</a></li>';
            } else {
                echo '<li class="list-group-item text-muted"><i class="fab fa-twitter me-2"></i>Twitter (Not Set)</li>';
            }
            if ($linkedin) {
                echo '<li class="list-group-item"><a href="' . esc_url($linkedin) . '" target="_blank" class="text-decoration-none"><i class="fab fa-linkedin-in me-2"></i>LinkedIn</a></li>';
            } else {
                echo '<li class="list-group-item text-muted"><i class="fab fa-linkedin-in me-2"></i>LinkedIn (Not Set)</li>';
            }
            if ($github) {
                echo '<li class="list-group-item"><a href="' . esc_url($github) . '" target="_blank" class="text-decoration-none"><i class="fab fa-github me-2"></i>GitHub</a></li>';
            } else {
                echo '<li class="list-group-item text-muted"><i class="fab fa-github me-2"></i>GitHub (Not Set)</li>';
            }
            if ($phone) {
                echo '<li class="list-group-item"><i class="fas fa-phone me-2"></i>' . esc_html($phone) . '</li>';
            } else {
                echo '<li class="list-group-item text-muted"><i class="fas fa-phone me-2"></i>Phone (Not Set)</li>';
            }
            echo '</ul>';

            echo '</div>';
        }

        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Author Info', 'socialinfo' );
        ?>
        <p>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'socialinfo' ); ?></label> 
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <?php 
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        return $instance;
    }
}

function register_author_info_widget() {
    register_widget( 'Author_Info_Widget' );
}
add_action( 'widgets_init', 'register_author_info_widget' );



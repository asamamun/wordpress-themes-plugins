<?php
/**
 * Plugin Name: Footer News Ticker
 * Description: Displays a news ticker at the bottom of your website with customization options.
 * Version: 1.3
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Default settings
function fnt_get_default_options() {
    return array(
        'fnt_active'     => 1, // 1 for active, 0 for inactive
        'fnt_bg_color'   => '#333333',
        'fnt_post_count' => 10,
    );
}

// Get options from the database, merging with defaults to prevent errors
function fnt_get_options() {
    $saved_options = get_option( 'fnt_settings' );

    if ( ! is_array( $saved_options ) ) {
        $saved_options = array();
    }

    return wp_parse_args( $saved_options, fnt_get_default_options() );
}

// Enqueue scripts and styles
function fnt_enqueue_assets() {
    $options = fnt_get_options();
    if ( ! $options['fnt_active'] ) {
        return; // Don't load assets if ticker is disabled
    }

    wp_enqueue_style( 'fnt-style', plugin_dir_url( __FILE__ ) . 'ticker-style.css' );
    wp_enqueue_script( 'fnt-script', plugin_dir_url( __FILE__ ) . 'ticker-script.js', array(), '1.0', true );

    $bg_color = esc_attr( $options['fnt_bg_color'] );
    $custom_css = ".news-ticker { background-color: {$bg_color}; }";
    wp_add_inline_style( 'fnt-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'fnt_enqueue_assets' );

// Ticker HTML
function fnt_display_ticker() {
    $options = fnt_get_options();
    if ( ! $options['fnt_active'] ) {
        return; // Don't display if not active
    }
    ?>
    <div class="news-ticker">
        <div class="ticker-container">
            <div class="ticker-label">LATEST NEWS</div>
            <div class="ticker-content">
                <ul class="ticker-list">
                    <?php
                    $args = array(
                        'post_type'      => 'post',
                        'post_status'    => 'publish',
                        'posts_per_page' => intval( $options['fnt_post_count'] ),
                    );
                    $latest_posts = new WP_Query( $args );
                    if ( $latest_posts->have_posts() ) {
                        while ( $latest_posts->have_posts() ) {
                            $latest_posts->the_post();
                            echo '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
                        }
                        wp_reset_postdata();
                    } else {
                        echo '<li>No recent posts found.</li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>
    <?php
}

add_action( 'wp_footer', 'fnt_display_ticker' );

// Shortcode
function fnt_ticker_shortcode() {
    ob_start();
    fnt_display_ticker();
    return ob_get_clean();
}
add_shortcode( 'latest_news_ticker', 'fnt_ticker_shortcode' );


// --- Settings Page ---

function fnt_add_settings_page() {
    add_options_page(
        'Footer Ticker Settings',
        'Footer Ticker',
        'manage_options',
        'fnt-settings',
        'fnt_render_settings_page'
    );
}
add_action( 'admin_menu', 'fnt_add_settings_page' );

// Register settings and add a sanitization callback
function fnt_register_settings() {
    register_setting(
        'fnt_settings_group',
        'fnt_settings',
        'fnt_sanitize_settings' // The callback function
    );
}
add_action( 'admin_init', 'fnt_register_settings' );

// Sanitize and validate the settings input
function fnt_sanitize_settings( $input ) {
    $new_input = array();

    // If the checkbox is checked, it will be set to '1'. If not, it won't be in the input array.
    // So we check if it's set, otherwise we set it to 0.
    $new_input['fnt_active'] = isset( $input['fnt_active'] ) ? 1 : 0;

    // Sanitize the color code
    if ( ! empty( $input['fnt_bg_color'] ) && preg_match( '/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/', $input['fnt_bg_color'] ) ) {
        $new_input['fnt_bg_color'] = $input['fnt_bg_color'];
    } else {
        // Fallback to default if the color is invalid
        $new_input['fnt_bg_color'] = '#333333';
    }

    // Sanitize the post count
    if ( isset( $input['fnt_post_count'] ) ) {
        $new_input['fnt_post_count'] = absint( $input['fnt_post_count'] ); // Ensures it's a positive integer
    } else {
        $new_input['fnt_post_count'] = 10;
    }

    return $new_input;
}


// Render the settings page
function fnt_render_settings_page() {
    $options = fnt_get_options();
    ?>
    <div class="wrap">
        <h1>Footer Ticker Settings</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'fnt_settings_group' );
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Activate Ticker</th>
                    <td>
                        <label>
                            <input type="checkbox" name="fnt_settings[fnt_active]" value="1" <?php checked( 1, $options['fnt_active'], true ); ?> />
                            Enable the news ticker in the footer.
                        </label>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Background Color</th>
                    <td>
                        <input type="text" name="fnt_settings[fnt_bg_color]" value="<?php echo esc_attr( $options['fnt_bg_color'] ); ?>" class="fnt-color-picker" />
                        <p class="description">Choose a background color for the ticker bar.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Number of Posts to Show</th>
                    <td>
                        <input type="number" name="fnt_settings[fnt_post_count]" value="<?php echo esc_attr( $options['fnt_post_count'] ); ?>" min="1" max="20" />
                        <p class="description">Enter the maximum number of recent posts to display in the ticker.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Enqueue color picker for admin settings page
function fnt_admin_enqueue_scripts( $hook ) {
    if ( 'settings_page_fnt-settings' !== $hook ) {
        return;
    }
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'fnt-admin-script', plugin_dir_url( __FILE__ ) . 'admin-script.js', array( 'wp-color-picker' ), false, true );
}
add_action( 'admin_enqueue_scripts', 'fnt_admin_enqueue_scripts' );

document.addEventListener('DOMContentLoaded', function() {
    const ticker = document.querySelector('.ticker-list');
    
    if (ticker) {
        ticker.addEventListener('mouseenter', function() {
            this.style.animationPlayState = 'paused';
        });
        
        ticker.addEventListener('mouseleave', function() {
            this.style.animationPlayState = 'running';
        });
    }
});

jQuery(document).ready(function($) {
    // Initialize the color picker
    $('.fnt-color-picker').wpColorPicker();
});

<?php
/* 
 Plugin Name: Test Plugin 
 Plugin URI: http://example.com/wordpress-plugins/halloween-plugin 
 Description: This is a brief description of my plugin 
 Version: 1.0
Author: IsDB BISEW
Author URI: http://example.com 
 Text Domain: round64
 License: GPLv2 
 */

register_activation_hook(__FILE__, 'test_install');
//deactivation hook
// register_deactivation_hook(__FILE__, 'test_uninstall');

register_uninstall_hook(__FILE__, 'test_uninstall');
function test_install()
{
    global $wp_version;

    if (version_compare($wp_version, '4.1', '<')) {
        wp_die('This plugin requires WordPress version 4.1 or higher.');
    }
    /*   $prowp_options_arr = array( 
 'test_display_mode' => 'Spooky', 
 'test_default_movie' => 'Halloween',
 'test_default_book' => 'Professional WordPress'
 );
   
 update_option( 'test_plugin_options', $prowp_options_arr ); */
    /*   $howdy = __( 'Howdy Neighbor!', 'prowp-plugin' ); 
 echo $howdy;
 _e( 'Howdy Neighbor!', 'prowp-plugin' );
 $count = 34;
 printf( _n( 'You have %d new message', 'You have %d new messages', $count, 'prowp-plugin'), $count ); */
    //echo plugin_dir_path( __FILE__ );
    //   wp_die( plugin_dir_path( __FILE__ ));
    //   wp_die(  __DIR__ );
    //   wp_die(  __FILE__ );
    // wp_die(plugins_url( ));
    // wp_die(plugin_dir_url( __FILE__ ));
}
function test_uninstall()
{

    delete_option('test_options');


}

//run this hook to add your plugin assets(js and css)
add_action('wp_enqueue_scripts', 'my_test_plugin_enqueue_scripts');
function my_test_plugin_enqueue_scripts()
{
    wp_enqueue_script(
        'my-test-plugin-script',
        plugin_dir_url(__FILE__) . 'test.js',
        null,
        '1.0.0',
        true
    );
    wp_enqueue_style(
        'my-test-plugin-style',
        plugin_dir_url(__FILE__) . 'test.css'
    );
}


// create custom plugin settings menu
add_action('admin_menu', 'test_create_menu');

function test_create_menu()
{

    //create new top-level menu
    add_menu_page(
        'Test Plugin Page',
        'Test Plugin',
        'manage_options',
        'prowp_main_menu',
        'test_main_plugin_page',
        plugins_url('star.png', __FILE__)
    );

    //create two sub-menus: settings and support
    add_submenu_page(
        'prowp_main_menu',
        'Halloween Settings Page',
        'Settings',
        'manage_options',
        'halloween_settings',
        'prowp_settings_page'
    );
    add_submenu_page(
        'prowp_main_menu',
        'Halloween Support Page',
        'Support',
        'manage_options',
        'halloween_support',
        'prowp_support_page'
    );

    //call register settings function
    add_action('admin_init', 'test_register_settings');
}

function test_register_settings()
{

    //register our settings 

    register_setting('test-settings-group', 'test_options', 'test_sanitize_options');

    //set default value for settings
    $test_options = get_option('test_options');
    if (false === $test_options) {
        add_option('test_options', array(
            'option_name' => 'John Doe',
            'option_email' => 'john@doe.com',
            'option_url' => 'http://example.com',
        ));
    }
}

function test_sanitize_options($input)
{

    $input['option_name'] =  sanitize_text_field($input['option_name']);
    $input['option_email'] =  sanitize_email($input['option_email']);
    $input['option_url'] =  esc_url($input['option_url']);
    return $input;
}

function test_main_plugin_page()
{

    echo '<h2>Test Plugin Page</h2>';
    echo '<p>This is the main page for the Test Plugin.</p>';
?>
    <form method="post" action="options.php">
        <?php settings_fields('test-settings-group'); ?>
        <?php $test_options = get_option('test_options'); ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Name</th>
                <td><input type="text" name="test_options[option_name]"
                        value="<?php echo esc_attr(
                                    $test_options['option_name']
                                ); ?>" /></td>
            </tr>

            <tr valign="top">
                <th scope="row">Email</th>
                <td><input type="text" name="test_options[option_email]"
                        value="<?php echo esc_attr(
                                    $test_options['option_email']
                                ); ?>" /></td>
            </tr>

            <tr valign="top">
                <th scope="row">URL</th>
                <td><input type="text" name="test_options[option_url]"
                        value="<?php echo esc_url($test_options['option_url']);
                                ?>" /></td>
            </tr>
        </table>

        <p class="submit">
            <input type="submit" class="button-primary" value="Save Changes" />
        </p>
    </form>
<?php
}
?>
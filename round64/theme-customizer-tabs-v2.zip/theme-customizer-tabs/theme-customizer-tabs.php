<?php
/**
 * Plugin Name: Theme Customizer Tabs
 * Description: Adds a theme customization panel with tabbed options using Bootstrap 5.3.
 * Version: 1.0
 * Author: Your Name
 */
//hooks
add_action('admin_menu', 'tct_add_admin_menu');
add_action('admin_init', 'tct_settings_init');
//uninstall
register_uninstall_hook(__FILE__, 'tct_uninstall');
function tct_uninstall() {
    delete_option('tct_options');
}

function tct_add_admin_menu() {
    add_theme_page('Theme Customizer', 'Theme Customizer', 'manage_options', 'theme_customizer', 'tct_options_page');
}

function tct_settings_init() {
    //set default values
    add_option('tct_options', array(
        'site_title' => 'test title',
        'layout_style' => 'wide',
        'primary_color' => 'light',
        'font_family' => 'Arial',

    ));
    register_setting('tct_settings_group', 'tct_options');
}

function tct_options_page() {
    $options = get_option('tct_options');
    var_dump($options);
    ?>
    <div class="wrap">
        <h1>Theme Customizer</h1>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

        <form method="post" action="options.php">
            <?php settings_fields('tct_settings_group'); ?>
            <ul class="nav nav-tabs" id="tctTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button" role="tab">General</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="layout-tab" data-bs-toggle="tab" data-bs-target="#layout" type="button" role="tab">Layout</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="colors-tab" data-bs-toggle="tab" data-bs-target="#colors" type="button" role="tab">Colors</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="typography-tab" data-bs-toggle="tab" data-bs-target="#typography" type="button" role="tab">Typography</button>
                </li>
            </ul>

            <div class="tab-content p-4 border border-top-0" id="tctTabContent">
                <div class="tab-pane fade show active" id="general" role="tabpanel">
                    <div class="mb-3">
                        <label for="site_title" class="form-label">Site Title</label>
                        <input type="text" class="form-control" id="site_title" name="tct_options[site_title]" value="<?php echo esc_attr($options['site_title'] ?? ''); ?>">
                    </div>
                </div>
                <div class="tab-pane fade" id="layout" role="tabpanel">
                    <div class="mb-3">
                        <label for="layout_style" class="form-label">Layout Style</label>
                        <select class="form-select" id="layout_style" name="tct_options[layout_style]">
                            <option value="full" <?php selected($options['layout_style'] ?? '', 'full'); ?>>Full Width</option>
                            <option value="boxed" <?php selected($options['layout_style'] ?? '', 'boxed'); ?>>Boxed</option>
                        </select>
                    </div>
                </div>
                <div class="tab-pane fade" id="colors" role="tabpanel">
                    <div class="mb-3">
                        <label for="primary_color" class="form-label">Primary Color</label>
                        <input type="color" class="form-control form-control-color" id="primary_color" name="tct_options[primary_color]" value="<?php echo esc_attr($options['primary_color'] ?? '#000000'); ?>">
                    </div>
                </div>
                <div class="tab-pane fade" id="typography" role="tabpanel">
                    <div class="mb-3">
                        <label for="font_family" class="form-label">Font Family</label>
                        <input type="text" class="form-control" id="font_family" name="tct_options[font_family]" value="<?php echo esc_attr($options['font_family'] ?? ''); ?>">
                    </div>
                </div>
            </div>

            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
